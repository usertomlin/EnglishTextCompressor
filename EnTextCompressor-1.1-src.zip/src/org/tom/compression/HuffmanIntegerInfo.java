package org.tom.compression;


import gnu.trove.map.hash.TIntIntHashMap;

import java.io.Serializable;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Map.Entry;

import org.tom.common.BinaryTree;
import org.tom.common.BitSet;
import org.tom.common.Frequencies;
import org.tom.common.MutableInt;
import org.tom.common.Pair;
import org.tom.utils.BitSetUtils;

/**
 * 
 * @author Tom3_Lin
 *
 */
public class HuffmanIntegerInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	private BinaryTree<Integer> decodeTree;
	private TIntIntHashMap encodePositionMap;

	public HuffmanIntegerInfo(BinaryTree<Integer> decodeTree, TIntIntHashMap encodePositionMap) {
		this.decodeTree = decodeTree;
		this.encodePositionMap = encodePositionMap;
	}
	
	/**
	 * should make sure the element exits
	 */
	public boolean[] getEncodeBits(int element){
		int position = encodePositionMap.get(element);
		return BitSetUtils.toTraversalBits(position);
	}
	
	public int getDecodedElement(BitSet bitSet, MutableInt offset){
		BinaryTree<Integer> target = decodeTree.traverseQuick(bitSet, offset);
		return target.getObject();
	}
	
	
	public static <T extends Comparable<T>> HuffmanIntegerInfo create(Frequencies<Integer> frequencies) {
		BinaryTree<Pair<Integer, Long>> treeWithValues = createHuffmanDecodeTreeWithValue(frequencies);
		BinaryTree<Integer> decodeTree = toTreeWithoutValues(treeWithValues);
		HashMap<Integer, Integer> encodePositionTempMap = decodeTree.getEncodePositionMap();
		
		TIntIntHashMap encodePositionMap = new TIntIntHashMap();
		Iterator<Entry<Integer, Integer>> iterator = encodePositionTempMap.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<Integer, Integer> entry = iterator.next();
			encodePositionMap.put(entry.getKey(), entry.getValue());
		}
		return new HuffmanIntegerInfo(decodeTree, encodePositionMap);
	}
 
	
	private static <K> BinaryTree<K> toTreeWithoutValues(BinaryTree<Pair<K, Long>> treeWithValues){
		if (treeWithValues == null)
			return null;
		BinaryTree<K> treeWithoutValues = new BinaryTree<K>();
		
		treeWithoutValues.setObject(treeWithValues.getObject() == null ? null : treeWithValues.getObject().getKey());
		if (treeWithValues.getLeft() != null){
			BinaryTree<K> left = toTreeWithoutValues(treeWithValues.getLeft());
			treeWithoutValues.setLeft(left);
		}
		if (treeWithValues.getRight() != null){
			BinaryTree<K> right = toTreeWithoutValues(treeWithValues.getRight());
			treeWithoutValues.setRight(right);
		}
		return treeWithoutValues;
	}
	
	private static <T extends Comparable<T>> BinaryTree<Pair<T, Long>> createHuffmanDecodeTreeWithValue(
			HashMap<T, Long> frequencies) {
		
		PriorityQueue<BinaryTree<Pair<T, Long>>> priorityQueue = new PriorityQueue<>(
			new Comparator<BinaryTree<Pair<T, Long>>>() {
				@Override
				public int compare(BinaryTree<Pair<T, Long>> o1, BinaryTree<Pair<T, Long>> o2) {
					return o1.getObject().getValue().compareTo(o2.getObject().getValue());
			}
		});

		Iterator<Entry<T, Long>> iterator = frequencies.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<T, Long> entry = iterator.next();
			Pair<T, Long> comparablePair = new Pair<T, Long>(entry.getKey(), entry.getValue());
			priorityQueue.add(new BinaryTree<Pair<T, Long>>(comparablePair));
		}
		while (priorityQueue.size() > 1) {
			BinaryTree<Pair<T, Long>> t1 = priorityQueue.poll();
			BinaryTree<Pair<T, Long>> t2 = priorityQueue.poll();
			BinaryTree<Pair<T, Long>> merged = new BinaryTree<Pair<T, Long>>(t1, t2);
			merged.setObject(new Pair<T, Long>(null, t1.getObject().getValue() + t2.getObject().getValue()));
			priorityQueue.add(merged);
		}
		return priorityQueue.peek();
	}

	
	
	

}
