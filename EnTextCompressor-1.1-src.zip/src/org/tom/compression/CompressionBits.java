package org.tom.compression;

import java.util.Arrays;

import org.tom.common.BitSet;


/**
 * 
 * @author Tom3_Lin
 */
public class CompressionBits {

	private BitSet bitSet;
	private int offset;
	
	public CompressionBits(BitSet bitSet, int offset) {
		this.bitSet = bitSet;
		this.offset = offset;
	}
	
	public CompressionBits(byte[] bytes) {
		this.bitSet = BitSet.valueOf(Arrays.copyOfRange(bytes, 1, bytes.length));
		this.offset = bytes[0] + bitSet.length();
	}
	
	/**
	 * @param length
	 */
	public CompressionBits(int length) {
		this.bitSet = new BitSet(length << 3);
		this.offset = 0;
	}

	public static CompressionBits fromCompressedBytes(byte[] bytes){
		if (bytes == null){
			return null;
		}
		if (bytes.length == 0){
			return new CompressionBits(1);
		}
		BitSet bitSet = BitSet.valueOf(Arrays.copyOfRange(bytes, 1, bytes.length));
		int offset = bytes[0] + bitSet.length();
		return new CompressionBits(bitSet, offset);
	}
	
	
	
	public byte[] toByteArray() {
		byte[] bits = bitSet.toByteArray();
		byte[] byteArray = new byte[bits.length + 1];
		
		/**byteArray[0]: store bitSet.length() - offset (with value 0 to 7)
		 * offset is always larger than or equal to bitSet.length();
		 * when decoding, byteArray[0] + bitSet.length() is offset
		 */
		byteArray[0] = (byte) (offset - bitSet.length());
		System.arraycopy(bits, 0, byteArray, 1, bits.length);
		return byteArray;
	}
	
	public static void main(String[] args) {
		
	}
	/**
	 * @return the bitSet
	 */
	public BitSet getBitSet() {
		return bitSet;
	}

	/**
	 * @param bitSet the bitSet to set
	 */
	public void setBitSet(BitSet bitSet) {
		this.bitSet = bitSet;
	}

	/**
	 * @return the offset
	 */
	public int getOffset() {
		return offset;
	}

	/**
	 * @param offset the offset to set
	 */
	public void setOffset(int offset) {
		this.offset = offset;
	}
	
	
	
}
