package org.tom.compression;

import java.io.ByteArrayInputStream;
import org.tom.common.BitSet;
import org.tom.common.MutableInt;
import org.tom.compression.CompressionBits;
import org.tom.compression.Token;
import org.tom.utils.FileUtils;


/**
 * @author Tom3_Lin
 */
public class EnTextCompressor {

	protected static final EnTextCompressionInfo enTextCompressionInfo; 
	static {
		
		PreTrainedCompressionData data = FileUtils.fromInputStream(
				EnTextCompressionInfo.class.getResourceAsStream("preTrainedCompressionData.ser.gz"));
		enTextCompressionInfo = EnTextCompressionInfo.create(data);
		
	}
	
	public static byte[] compress(String enText){
		if (enText == null){
			return null;
		}
		if (enText.length() == 0){
			return new byte[0];
		}
		
		CompressionBits compressionBits = enTextCompressionInfo.tokenizeToBits(enText);
		return compressionBits.toByteArray();
	}
	

	public static String uncompress(byte[] byteArray){
		if (byteArray == null)
			return null;
		if (byteArray.length == 0){
			return "";
		}
		CompressionBits compressionBits = CompressionBits.fromCompressedBytes(byteArray);
		BitSet bitSet = compressionBits.getBitSet();
		final int numBits = compressionBits.getOffset();
		return uncompress(bitSet, numBits);
	}
	
	private static String uncompress(BitSet bitSet, final int numBits){
		StringBuilder builder = new StringBuilder();
		MutableInt offset = new MutableInt();
		final int numBitsMinus1 = numBits - 1;
		byte posIndex = enTextCompressionInfo.decodeAfterWord(bitSet, offset, builder, Token.PERIODPosIndex);
		while (offset.isSmallerThan(numBitsMinus1)){
			if (posIndex > 0) {
				posIndex = enTextCompressionInfo.decodeAfterWord(bitSet, offset, builder, posIndex);
			} else {
				posIndex = enTextCompressionInfo.decodeAfterCharSequence(bitSet, offset, builder, posIndex);
			}
		}
		
		if (posIndex > 0 && bitSet.get(numBitsMinus1)){
			builder.append(' ');
		}
		
		return builder.toString();
	}

	//////////////////////////////////////////////////////////
	
	protected static void showErrorMessage() {
		System.out.println("Specify -c or -uc for compression or uncompression in argument 1"
				+ ", and specify input file path in argument 2 and (optionally) output path in argument 3");
	}
	
	protected static String getOutputPath(String[] args, String suffix) {
		if (args.length > 2){
			return args[2];
		}
		String inputPath = args[1];
		String outputPath = null; 
		if (inputPath.endsWith(suffix)){
			outputPath  = inputPath.substring(0, inputPath.length() - suffix.length());
		} else {
			outputPath = inputPath + ".uncompressed";
		}
		return outputPath;
	}
	
	/**
	 * takes 2 or 3 arguments;
	 * arg 1: must be -c or -uc for compression or uncompression
	 * 
	 * Example: 
	 * java -jar EnTextCompressor-1.1.jar -c "D:\Temp\posBigramFrequencies.txt"
	 * 
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		if (args.length <= 1){
			showErrorMessage();
			return;
		}
		final String suffix =  ".etz";
		String inputPath = args[1];
		String outputPath = null;
		
		switch (args[0].toLowerCase()) {
		case "-c":
			outputPath = args.length == 2 ? (inputPath + suffix) : args[2];
			String enText = FileUtils.read(args[1]);
			byte[] bytes = EnTextCompressor.compress(enText);
			FileUtils.writeInputStream(new ByteArrayInputStream(bytes), outputPath);
			System.out.println("Successfully write the compressed text to " + outputPath);
			break;
		case "-uc":
			outputPath = getOutputPath(args, suffix);
			bytes = FileUtils.readBytes(inputPath);
			String text = EnTextCompressor.uncompress(bytes);
			FileUtils.write(text, outputPath);
			System.out.println("Successfully write the uncompressed text to " + outputPath);
			break;
		default:
			showErrorMessage();
			break;
		}
		
		
	}
	
}
