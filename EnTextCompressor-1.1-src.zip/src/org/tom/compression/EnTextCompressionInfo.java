package org.tom.compression;

import gnu.trove.map.hash.TCharByteHashMap;
import gnu.trove.map.hash.TIntIntHashMap;
import gnu.trove.map.hash.TObjectByteHashMap;
import gnu.trove.map.hash.TObjectIntHashMap;
import gnu.trove.set.hash.TIntHashSet;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;

import org.tom.common.BitSet;
import org.tom.common.Frequencies;
import org.tom.common.MutableInt;
import org.tom.common.Pair;
import org.tom.common.Quadruple;
import org.tom.common.Triple;
import org.tom.common.WordInfo;
import org.tom.compression.Token;
import org.tom.compression.HuffmanByteInfo;
import org.tom.compression.HuffmanInfo;
import org.tom.compression.HuffmanIntegerInfo;


import org.tom.compression.Token.Tokens;
import org.tom.utils.BitSetUtils;
import org.tom.utils.ObjectSerializer;



/**
 * one HashMap<String, Integer> enCharToPositionMap,
 * one BinaryTree<String> enCharDecodeTree,
 * 
 * one HashMap<String, WordType> 
 * 
 * @author Tom3_Lin
 */
public class EnTextCompressionInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	//key: words; value: word indices
	private TObjectIntHashMap<String> wordIndexMap;
	
	//key: word indices; value: words;
	private String[] wordArray;

	//key: word indices; value: pos indices;
	private byte[] startPosIndexArray;
	private byte[] endPosIndexArray;
	
	//about pos transition; corresponding to different poses; element: pos indices
	private ArrayList<HuffmanByteInfo> posesHuffmanInfos;
	//corresponding to words of different poses; element: word indices
	private ArrayList<HuffmanIntegerInfo> posesWordsHuffmanInfos;

	//for encoding non-word char sequences
	private HuffmanInfo<String> charsHuffmanInfo;

	//used to speed up checking 2-4 grams 
	private byte[] wordBigramEndInfo;
	
	private TCharByteHashMap maxSyllableLengthsMap;

	private TIntIntHashMap bigramIndexMap;

	private TIntHashSet bigramStartSet;
	
	
	////////////////////////////////////////////////////

	/**
	 * @return the wordIndexMap
	 */
	public TObjectIntHashMap<String> getWordIndexMap() {
		return wordIndexMap;
	}

	/**
	 * @param wordIndexMap the wordIndexMap to set
	 */
	public void setWordIndexMap(TObjectIntHashMap<String> wordIndexMap) {
		this.wordIndexMap = wordIndexMap;
	}

	/**
	 * @return the wordArray
	 */
	public String[] getWordArray() {
		return wordArray;
	}

	/**
	 * @param wordArray the wordArray to set
	 */
	public void setWordArray(String[] wordArray) {
		this.wordArray = wordArray;
	}

	/**
	 * @return the wordPosIndexArray
	 */
	public byte[] getStartPosIndexArray() {
		return startPosIndexArray;
	}

	/**
	 * @param wordPosIndexArray the wordPosIndexArray to set
	 */
	public void setStartPosIndexArray(byte[] wordPosIndexArray) {
		this.startPosIndexArray = wordPosIndexArray;
	}

	/**
	 * @return the endPosIndexArray
	 */
	public byte[] getEndPosIndexArray() {
		return endPosIndexArray;
	}

	/**
	 * @param endPosIndexArray the endPosIndexArray to set
	 */
	public void setEndPosIndexArray(byte[] endPosIndexArray) {
		this.endPosIndexArray = endPosIndexArray;
	}

	
	/**
	 * @return the posesHuffmanInfos
	 */
	public ArrayList<HuffmanByteInfo> getPosesHuffmanInfos() {
		return posesHuffmanInfos;
	}

	/**
	 * @param posesHuffmanInfos the posesHuffmanInfos to set
	 */
	public void setPosesHuffmanInfos(ArrayList<HuffmanByteInfo> posesHuffmanInfos) {
		this.posesHuffmanInfos = posesHuffmanInfos;
	}

	/**
	 * @return the posesWordsHuffmanInfos
	 */
	public ArrayList<HuffmanIntegerInfo> getPosesWordsHuffmanInfos() {
		return posesWordsHuffmanInfos;
	}

	/**
	 * @param posesWordsHuffmanInfos the posesWordsHuffmanInfos to set
	 */
	public void setPosesWordsHuffmanInfos(ArrayList<HuffmanIntegerInfo> posesWordsHuffmanInfos) {
		this.posesWordsHuffmanInfos = posesWordsHuffmanInfos;
	}

	/**
	 * @return the charsHuffmanInfo
	 */
	public HuffmanInfo<String> getCharsHuffmanInfo() {
		return charsHuffmanInfo;
	}

	/**
	 * @param charsHuffmanInfo the charsHuffmanInfo to set
	 */
	public void setCharsHuffmanInfo(HuffmanInfo<String> charsHuffmanInfo) {
		this.charsHuffmanInfo = charsHuffmanInfo;
	}

	
	
	/**
	 * @return the wordNGramEndInfo
	 */
	public byte[] getWordBigramEndInfo() {
		return wordBigramEndInfo;
	}

	/**
	 * @param wordBigramEndInfo the wordBigramEndInfo to set
	 */
	public void setWordBigramEndInfo(byte[] wordBigramEndInfo) {
		this.wordBigramEndInfo = wordBigramEndInfo;
	}
	
	/**
	 * @return the maxSyllableLengthsMap
	 */
	public TCharByteHashMap getMaxSyllableLengthsMap() {
		return maxSyllableLengthsMap;
	}

	/**
	 * @param maxSyllableLengthsMap the maxSyllableLengthsMap to set
	 */
	public void setMaxSyllableLengthsMap(TCharByteHashMap maxSyllableLengthsMap) {
		this.maxSyllableLengthsMap = maxSyllableLengthsMap;
	}
	
	/**@return the bigramIndexMap
	 */
	public TIntIntHashMap getBigramIndexMap() {
		return bigramIndexMap;
	}

	/**@param bigramIndexMap the bigramIndexMap to set
	 */
	public void setBigramIndexMap(TIntIntHashMap bigramIndexMap) {
		this.bigramIndexMap = bigramIndexMap;
	}

	/**
	 * @return the bigramStartSet
	 */
	public TIntHashSet getBigramStartSet() {
		return bigramStartSet;
	}

	/**
	 * @param bigramStartSet the bigramStartSet to set
	 */
	public void setBigramStartSet(TIntHashSet bigramStartSet) {
		this.bigramStartSet = bigramStartSet;
	}


	////////////////////////////////////////////////////
	
	/**
	 * key: pos
	 * value: index 
	 */
	private static TObjectByteHashMap<String> createPosIndexMap(HashMap<String, WordInfo> wordInfoMap) {
		Iterator<Entry<String, WordInfo>> iterator = wordInfoMap.entrySet().iterator();
		
		HashSet<String> posSet = new HashSet<String>();
		while (iterator.hasNext()){
			Entry<String, WordInfo> entry = iterator.next();
			posSet.add(entry.getValue().getPos());
		}
		TObjectByteHashMap<String> posIndexMap = new TObjectByteHashMap<String>();
		
		ArrayList<String> posList = new ArrayList<String>(posSet);
		Collections.sort(posList);
		byte index = 1;
		for(String pos : posList){
			posIndexMap.put(pos, index++);
		}
		return posIndexMap;
	}
	
	private static ArrayList<Frequencies<Byte>> createNextPosFrequencies(Frequencies<String> posBigramFrequencies, 
			TObjectByteHashMap<String> posIndexMap) {
		
		ArrayList<Frequencies<Byte>> posToPosFrequencies = new ArrayList<Frequencies<Byte>>(posIndexMap.size() + 1);
		posToPosFrequencies.add(null);
		for (int i = 0; i < posIndexMap.size(); i++) {
			posToPosFrequencies.add(new Frequencies<Byte>());
		}
		
		Iterator<Entry<String, Long>> iterator = posBigramFrequencies.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<String, Long> entry = iterator.next();
			
			String posBigram = entry.getKey();
			String[] twoPoses = posBigram.split("-");
			byte firstPosIndex = posIndexMap.get(twoPoses[0]);
			byte secondPosIndex = posIndexMap.get(twoPoses[1]);
			Frequencies<Byte> theFreqToAdd = posToPosFrequencies.get(firstPosIndex);
			theFreqToAdd.addFrequency(secondPosIndex, entry.getValue());
		}
		return posToPosFrequencies;
	}
	
	private static ArrayList<Frequencies<Integer>> getPosWordsPhrasesFrequencies(byte[] wordPosIndexArray, String[] wordArray, HashMap<String, WordInfo> wordInfoMap, final int numPoses) {
		
		ArrayList<Frequencies<Integer>> posWordsFrequencies = new ArrayList<Frequencies<Integer>>(numPoses + 1);
		posWordsFrequencies.add(null);
		for (int i = 0; i < numPoses; i++) {
			posWordsFrequencies.add(new Frequencies<Integer>());
		}
		
		for (int i = 1; i < wordPosIndexArray.length; i++) {
			byte posIndex = wordPosIndexArray[i];
			Frequencies<Integer> freqsToAdd = posWordsFrequencies.get(posIndex);
			String word = wordArray[i];
			if (word == null)
				continue;
			long wordFreq = wordInfoMap.get(word).getFrequency();
			freqsToAdd.addFrequency(i, wordFreq);
		}
		return posWordsFrequencies;
	}
	
	
	private static ArrayList<Frequencies<Integer>> getPosWordsFrequencies(
			Frequencies<Tokens> recountedFrequencies, EnTextCompressionInfo enTextCompressionInfo) {
		
		TObjectIntHashMap<String> wordIndexMap = enTextCompressionInfo.getWordIndexMap();
		byte[] wordPosIndexArray = enTextCompressionInfo.getStartPosIndexArray();
		int numPoses = enTextCompressionInfo.getPosesHuffmanInfos().size() - 1;
		ArrayList<Frequencies<Integer>> posWordsFrequencies = new ArrayList<Frequencies<Integer>>(numPoses + 1);
		posWordsFrequencies.add(null);
		for (int i = 0; i < numPoses; i++) {
			posWordsFrequencies.add(new Frequencies<Integer>());
		}
		
		Iterator<Entry<Tokens, Long>> iterator = recountedFrequencies.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<Tokens, Long> entry = iterator.next();
			Tokens key = entry.getKey();
			String firstWord = key.get(0).getToken();
			int firstWordIndex = wordIndexMap.get(firstWord);
			if (firstWordIndex <= 0){
				System.out.println("Ignore this: firstWordIndex = " + firstWordIndex + ", firstWord = " + firstWord);
				continue;
			}
			
			long wordFreq = entry.getValue();
			//index for pos words frequencies
			byte startPosIndex = wordPosIndexArray[firstWordIndex];
			
			String wholePhrase = key.toString();
			int wholePhraseIndex = wordIndexMap.get(wholePhrase);
			if (wholePhraseIndex <= 0){
				throw new Error("Bugs had occurred");
			}
			
			Frequencies<Integer> freqsToAdd = posWordsFrequencies.get(startPosIndex);
			freqsToAdd.addFrequency(wholePhraseIndex, wordFreq);
		}
		
		
		return posWordsFrequencies;
	}
	
	
	private static final byte[] charToProbablePos = setCharToProbablePos();
	private static byte[] setCharToProbablePos() {
		byte[] bs = new byte[128];
		for (char c = '0'; c <= '9'; c++) { bs[c] = 1;} 
		for (char c = 'a'; c <= 'z'; c++) { bs[c] = 2;}
		for (char c = 'A'; c <= 'Z'; c++) {	bs[c] = 3;}
		bs[' '] = 4;
		return bs;
	}
	
	private static final byte CD = 3;
	private static final byte NNS = 24;
	private static final byte NN = 20;
	private static final byte NNPS_C = 22;
	private static final byte NNP_C = 23;
	
	

	protected static void recreateCompressionInfo() {
		EnTextCompressionInfo enTextCompressionInfo = 
				ObjectSerializer.deserialize("D:/Temp/enTextCompressionInfo.ser - old.gz", true);
		Frequencies<String> enWordPhraseFrequencies = 
				ObjectSerializer.deserialize("D:/Temp/enWordPhraseFrequencies.ser.gz", true);
		
		byte[] wordPosIndexArray = enTextCompressionInfo.getStartPosIndexArray();

		final int numPoses = enTextCompressionInfo.getPosesHuffmanInfos().size() - 1;
		
		System.out.println("enWordPhraseFrequencies.size() = " + enWordPhraseFrequencies.size());

		String[] oldWordArray = enTextCompressionInfo.getWordArray();
		
		Frequencies<Tokens> recountedFrequencies = 
				ObjectSerializer.deserialize("D:/Temp/recountedFrequencies.ser - Copy.gz", true);
		

		Iterator<Entry<Tokens, Long>> iterator = recountedFrequencies.entrySet().iterator();
	
		String[] wordArray = new String[recountedFrequencies.size() + 1];
		System.arraycopy(oldWordArray, 1, wordArray, 1, oldWordArray.length - 1);
		TObjectIntHashMap<String> wordIndexMap = new TObjectIntHashMap<String>(wordArray.length);
		
//		System.out.println("wordIndexMap.size() = " + enTextCompressionInfo.getWordIndexMap().size());
//		System.out.println("System.exit(0) at EnTextCompressionInfo.recreateCompressionInfo()");
//		System.exit(0);

		wordIndexMap.putAll(enTextCompressionInfo.getWordIndexMap());

		int index = oldWordArray.length;
		while (iterator.hasNext()){
			Entry<Tokens, Long> entry = iterator.next();
			Tokens key = entry.getKey();
			if (key.size() == 1){
				continue;
			}
			String keyString = key.toString();
			wordArray[index] = keyString;
			wordIndexMap.put(keyString, index);
			index++;
		}
		
		enTextCompressionInfo.setWordArray(wordArray);
		enTextCompressionInfo.setWordIndexMap(wordIndexMap);
		
		//re-create enTextCompressionInfo.getPosesWordsHuffmanInfos();
		
		ArrayList<Frequencies<Integer>> posWordsFrequencies = 
				getPosWordsFrequencies(recountedFrequencies, enTextCompressionInfo);
		ArrayList<HuffmanIntegerInfo> posesWordsHuffmanInfos = new ArrayList<HuffmanIntegerInfo>(numPoses + 1);
		posesWordsHuffmanInfos.add(null);
		for (int i = 1; i <= numPoses; i++) {
			Frequencies<Integer> frequencies = posWordsFrequencies.get(i); 
			HuffmanIntegerInfo info = HuffmanIntegerInfo.create(frequencies);
			posesWordsHuffmanInfos.add(info);
		}
		
		byte[] wordNGramEndInfo = ObjectSerializer.deserialize("D:/Temp/wordNGramEndInfo.ser.gz", true);
		
		EnTextCompressionInfo enCompressionInfo = new EnTextCompressionInfo();
		
		enCompressionInfo.wordIndexMap = wordIndexMap;
		enCompressionInfo.wordArray = wordArray;
		enCompressionInfo.startPosIndexArray = wordPosIndexArray;
		enCompressionInfo.posesHuffmanInfos = enTextCompressionInfo.getPosesHuffmanInfos();
		enCompressionInfo.posesWordsHuffmanInfos = posesWordsHuffmanInfos;
		enCompressionInfo.charsHuffmanInfo = enTextCompressionInfo.getCharsHuffmanInfo();
		enCompressionInfo.wordBigramEndInfo = wordNGramEndInfo;
		ObjectSerializer.serialize(enCompressionInfo, "D:/Temp/enTextCompressionInfo.ser.gz", true);
		
		System.exit(0);
	}
	
	protected static void manuallyAdjustSomeEntries(HashMap<String, WordInfo> wordInfoMap) {
		wordInfoMap.remove("9E9E9");
		wordInfoMap.remove("CiconiiformesFamily");
		wordInfoMap.remove("PelecaniformesFamily");
		wordInfoMap.remove("CoraciiformesFamily");
		wordInfoMap.remove("GruiformesFamily");
		wordInfoMap.remove("FalconiformesFamily");
		
		wordInfoMap.put("ly", new WordInfo("RB", 320000L));
		wordInfoMap.get("ing").setPos("VBG");
		
	}
	
	
	public static EnTextCompressionInfo create(PreTrainedCompressionData data) {
		
		HashMap<String, WordInfo> wordInfoMap = data.wordInfoMap;
		Frequencies<String> topCharsFrequencies = data.topCharsFrequencies;
		Frequencies<String> posBigramFrequencies = data.posBigramFrequencies;
		
		
		//a temporary map; pos Strings are no longer used afterwards
		/**
		 * {EX_C=9,WP_C=60,CD_C=4,OTHER_C=28,WRB_C=62,CC=1,PERIOD=29,IN=10,
		 * CD=3,JJ=12,VB=44,VBG_C=48,RBS=39,RBR=37,JJ_C=17,RBR_C=38,NNPS_C=22,
		 * PRP_C=34,VBP_C=52,JJR_C=14,NN=20,NNS_C=25,PRP$=32,WRB=61,TO=42,COMMA=5,
		 * VBN=49,VBN_C=50,CC_C=2,PRP=31,WDT=56,VBZ_C=54,PRP$_C=33,MD=18,VB_C=55,
		 * TO_C=43,VBZ=53,RB_C=40,VBP=51,RP=41,EX=8,VBG=47,VBD=45,OTHER=27,DT_C=7,
		 * RB=36,NN_C=26,MD_C=19,VBD_C=46,NNS=24,NNP=21,WP$=59,DT=6,POS=30,WDT_C=57,
		 * WP=58,IN_C=11,JJS_C=16,JJS=15,JJR=13,NNP_C=23,PU=35}
		 */
		TObjectByteHashMap<String> posIndexMap = createPosIndexMap(wordInfoMap);
		
		ArrayList<Entry<String, WordInfo>> wordIfoEntries = new ArrayList<Entry<String,WordInfo>>();
		Iterator<Entry<String, WordInfo>> iterator = wordInfoMap.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<String, WordInfo> entry = iterator.next();
			wordIfoEntries.add(entry);
		}


		final int numWordAndPhrases = wordIfoEntries.size();
		final int numPoses = posIndexMap.size();
		
		TObjectIntHashMap<String> wordIndexMap = new TObjectIntHashMap<String>(numWordAndPhrases);
		String[] wordArray = new String[numWordAndPhrases + 1];
		byte[] startPosIndexArray = new byte[numWordAndPhrases + 1];
		byte[] endPosIndexArray = new byte[numWordAndPhrases + 1];
		
		Collections.sort(wordIfoEntries, new Comparator<Entry<String, WordInfo>>() {
			// for managing uni-gram word indices 
			@Override
			public int compare(Entry<String, WordInfo> o1, Entry<String, WordInfo> o2) {
				WordInfo wi1 = o1.getValue(); WordInfo wi2 = o2.getValue();
				if (wi1.isPhrase() == false && wi2.isPhrase() == true) {
					return -1;
				} else if (wi1.isPhrase() == true && wi2.isPhrase() == false){
					return 1;
				}
				return o1.getKey().length() - o2.getKey().length();
			}
		});
		
		TIntHashSet bigramStartSet = new TIntHashSet();
		TIntIntHashMap bigramIndexMap = new TIntIntHashMap(numWordAndPhrases >> 1);
		
		int index = 1;
		for (Entry<String, WordInfo> wordInfoEntry : wordIfoEntries) {
			String word = wordInfoEntry.getKey();
			
			WordInfo info = wordInfoEntry.getValue();
			if (info.isPhrase() == true){
				
				String w1 = info.getWord1();
				String w2 = info.getWord2();
				int i1 = wordIndexMap.get(w1);
				int i2 = wordIndexMap.get(w2);
				if ((i1 > 0 && i2 > 0) == false){
					throw new Error("wegfr");
				}
				
				bigramIndexMap.put(getBigramMapKey(i1, i2), index);
				String startPos = info.getPos();
				String endPos = info.getEndPos();
				byte startPosIndex = posIndexMap.get(startPos);
				byte endPosIndex = posIndexMap.get(endPos);
				wordArray[index] = word;
				startPosIndexArray[index] = startPosIndex;
				endPosIndexArray[index] = endPosIndex; 
				wordIndexMap.put(word, index);
				index++;
				bigramStartSet.add(i1);
				continue;
			}
			
			String startPos = info.getPos();
			String endPos = info.getEndPos();
			if (endPos == null){
				endPos = startPos;
			}
			byte startPosIndex = posIndexMap.get(startPos);
			byte endPosIndex = posIndexMap.get(endPos);
			wordArray[index] = word;
			startPosIndexArray[index] = startPosIndex;
			endPosIndexArray[index] = endPosIndex; 
			wordIndexMap.put(word, index);
			index++;
		}
		
		ArrayList<Frequencies<Byte>> posToPosFrequencies = createNextPosFrequencies(posBigramFrequencies, posIndexMap);
		ArrayList<HuffmanByteInfo> posesHuffmanInfos = new ArrayList<HuffmanByteInfo>(numPoses + 1);
		posesHuffmanInfos.add(null);
		for (int posIndex = 1; posIndex <= numPoses; posIndex++){  
			Frequencies<Byte> bigramPosFreq = posToPosFrequencies.get(posIndex);
			HuffmanByteInfo huffmanInfo = HuffmanByteInfo.create(bigramPosFreq);
			posesHuffmanInfos.add(huffmanInfo);
		}
		
		ArrayList<Frequencies<Integer>> posWordsFrequencies = getPosWordsPhrasesFrequencies(startPosIndexArray, wordArray, wordInfoMap, numPoses);
		
		ArrayList<HuffmanIntegerInfo> posesWordsHuffmanInfos = new ArrayList<HuffmanIntegerInfo>(numPoses + 1);
		posesWordsHuffmanInfos.add(null);
		for (int i = 1; i <= numPoses; i++) {
			Frequencies<Integer> frequencies = posWordsFrequencies.get(i); 
			HuffmanIntegerInfo info = HuffmanIntegerInfo.create(frequencies);
			posesWordsHuffmanInfos.add(info);
		}
		
		topCharsFrequencies.remove("★");
		TCharByteHashMap maxSyllableLengthsMap = createMaxSyllableLengths(topCharsFrequencies);
		
		HuffmanInfo<String> charsHuffmanInfo = HuffmanInfo.create(topCharsFrequencies);
		
		EnTextCompressionInfo enCompressionInfo = new EnTextCompressionInfo();
		
		
		enCompressionInfo.wordIndexMap = wordIndexMap;

		enCompressionInfo.wordArray = wordArray;
		enCompressionInfo.startPosIndexArray = startPosIndexArray;
		enCompressionInfo.endPosIndexArray = endPosIndexArray;
		enCompressionInfo.posesHuffmanInfos = posesHuffmanInfos;
		enCompressionInfo.posesWordsHuffmanInfos = posesWordsHuffmanInfos;
		enCompressionInfo.charsHuffmanInfo = charsHuffmanInfo;
		enCompressionInfo.maxSyllableLengthsMap = maxSyllableLengthsMap;
		enCompressionInfo.bigramIndexMap = bigramIndexMap;
		enCompressionInfo.bigramStartSet = bigramStartSet;
		
		return enCompressionInfo;
	}
	
	
//	public static EnTextCompressionInfo create_old(PreTrainedCompressionData data) {
//		
//		HashMap<String, WordInfo> wordInfoMap = data.wordInfoMap;
//		Frequencies<String> topCharsFrequencies = data.topCharsFrequencies;
//		Frequencies<String> posBigramFrequencies = data.posBigramFrequencies;
//		
//		
//		//a temporary map; pos Strings are no longer used afterwards
//		/**
//		 * {EX_C=9,WP_C=60,CD_C=4,OTHER_C=28,WRB_C=62,CC=1,PERIOD=29,IN=10,
//		 * CD=3,JJ=12,VB=44,VBG_C=48,RBS=39,RBR=37,JJ_C=17,RBR_C=38,NNPS_C=22,
//		 * PRP_C=34,VBP_C=52,JJR_C=14,NN=20,NNS_C=25,PRP$=32,WRB=61,TO=42,COMMA=5,
//		 * VBN=49,VBN_C=50,CC_C=2,PRP=31,WDT=56,VBZ_C=54,PRP$_C=33,MD=18,VB_C=55,
//		 * TO_C=43,VBZ=53,RB_C=40,VBP=51,RP=41,EX=8,VBG=47,VBD=45,OTHER=27,DT_C=7,
//		 * RB=36,NN_C=26,MD_C=19,VBD_C=46,NNS=24,NNP=21,WP$=59,DT=6,POS=30,WDT_C=57,
//		 * WP=58,IN_C=11,JJS_C=16,JJS=15,JJR=13,NNP_C=23,PU=35}
//		 */
//		TObjectByteHashMap<String> posIndexMap = createPosIndexMap(wordInfoMap);
//		
//		final int numWords = wordInfoMap.size();
//		final int numPoses = posIndexMap.size();
//		
//		TObjectIntHashMap<String> wordIndexMap = new TObjectIntHashMap<String>(numWords);
//		String[] wordArray = new String[numWords + 1];
//		byte[] wordPosIndexArray = new byte[numWords + 1];
//		
//		ArrayList<ComparablePair<String, Integer>> wordIndexPairs = new ArrayList<>(numWords + 1);
//		
//		Iterator<Entry<String, WordInfo>> iterator = wordInfoMap.entrySet().iterator();
//		int index = 1;
//		while (iterator.hasNext()){
//			Entry<String, WordInfo> entry = iterator.next();
//			String word = entry.getKey();
//			String pos = entry.getValue().getPos();
//			byte posIndex = posIndexMap.get(pos);
//			wordArray[index] = word;
//			wordPosIndexArray[index] = posIndex;
//			wordIndexMap.put(word, index);
//			wordIndexPairs.add(new ComparablePair<String, Integer>(word, index));
//			index++;
//		}
//		
//		Collections.sort(wordIndexPairs, ComparablePair.ascendingValueComparator());
//
//		
//		ArrayList<Frequencies<Byte>> posToPosFrequencies = createNextPosFrequencies(posBigramFrequencies, posIndexMap);
//		
//		ArrayList<HuffmanByteInfo> posesHuffmanInfos = new ArrayList<HuffmanByteInfo>(numPoses + 1);
//		posesHuffmanInfos.add(null);
//		for (int posIndex = 1; posIndex <= numPoses; posIndex++){  
//			Frequencies<Byte> bigramPosFreq = posToPosFrequencies.get(posIndex);
//			HuffmanByteInfo huffmanInfo = HuffmanByteInfo.create(bigramPosFreq);
//			posesHuffmanInfos.add(huffmanInfo);
//		}
//		
//		ArrayList<Frequencies<Integer>> posWordsFrequencies = getPosWordsFrequencies_old(wordPosIndexArray, wordArray, wordInfoMap, numPoses);
//		
//		ArrayList<HuffmanIntegerInfo> posesWordsHuffmanInfos = new ArrayList<HuffmanIntegerInfo>(numPoses + 1);
//		posesWordsHuffmanInfos.add(null);
//		for (int i = 1; i <= numPoses; i++) {
//			Frequencies<Integer> frequencies = posWordsFrequencies.get(i); 
//			HuffmanIntegerInfo info = HuffmanIntegerInfo.create(frequencies);
//			posesWordsHuffmanInfos.add(info);
//		}
//		
//		topCharsFrequencies.remove("★");
//		TCharByteHashMap maxSyllableLengthsMap = createMaxSyllableLengths(topCharsFrequencies);
//		
//		HuffmanInfo<String> charsHuffmanInfo = HuffmanInfo.create(topCharsFrequencies);
//		
//		
//		EnTextCompressionInfo enCompressionInfo = new EnTextCompressionInfo();
//		
//		enCompressionInfo.wordIndexMap = wordIndexMap;
//		enCompressionInfo.wordArray = wordArray;
//		enCompressionInfo.startPosIndexArray = wordPosIndexArray;
//		enCompressionInfo.posesHuffmanInfos = posesHuffmanInfos;
//		enCompressionInfo.posesWordsHuffmanInfos = posesWordsHuffmanInfos;
//		enCompressionInfo.charsHuffmanInfo = charsHuffmanInfo;
//		enCompressionInfo.maxSyllableLengthsMap = maxSyllableLengthsMap;
//		
//		return enCompressionInfo;
//	}
	
	protected static TCharByteHashMap createMaxSyllableLengths(Frequencies<String> topCharsFrequencies) {
		TCharByteHashMap map = new TCharByteHashMap();
		Iterator<Entry<String, Long>> iterator = topCharsFrequencies.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<String, Long> entry = iterator.next();
			String key = entry.getKey();
			
			char lastChar = key.charAt(key.length() - 1);
			int bt = map.get(lastChar);
			if (bt < key.length()){
				map.put(lastChar, (byte) key.length());
			}
		}
		return map;
	}
	
	
	
	public byte getPosIndex(int wordIndex) {
		return startPosIndexArray[wordIndex];
	}

	public boolean[] getPosTransitionBits(byte posIndex1, byte posIndex2){
		HuffmanByteInfo info = posesHuffmanInfos.get(posIndex1);
		return info.getEncodeBits(posIndex2);
	}
	
	
	
	
	private static final byte ORDINARY = 0;
	private static final byte RARE1 = 1;
	private static final byte RARE2 = 2;
	
	/**
	 * save time for calling 'Collections.reverse(bitsList);'
	 * @param charSequence
	 */
	public ArrayList<boolean[]> tokenizeByCharsInReverseOrder(String charSequence) {
		charSequence = charSequence + '\0';
		int endIndex = charSequence.length();
		
		TObjectIntHashMap<String> encodePositionMap = charsHuffmanInfo.getEncodePositionMap();
		ArrayList<boolean[]> bitsList = new ArrayList<boolean[]>();
		while (endIndex > 0) {
			Triple<String, Integer, Byte> triple = getLongestSyllable(charSequence, endIndex, encodePositionMap);
			String chars = triple.getFirst();
			endIndex = triple.getSecond();
			switch (triple.getThird()){
				case ORDINARY: break;
				case RARE1: //10 bits
					char codePoint = charSequence.charAt(endIndex);
					bitsList.add(BitSetUtils.toBits(codePoint, 10));break;
				case RARE2: //16 bits
					codePoint = charSequence.charAt(endIndex);
					bitsList.add(BitSetUtils.toBits(codePoint, 16));break;
			}
			bitsList.add(charsHuffmanInfo.getEncodeBits(chars));
		}
		return bitsList;
	}
	
	
	/**@param charSequence
	 * @param endIndex
	 * @return triple
	 * first: char or syllable 
	 * second: end index of String 'first'
	 * Byte: a rare character or not: 0, 1, 2, or 3
	 */
	protected Triple<String, Integer, Byte> getLongestSyllable(String charSequence, int endIndex, 
			TObjectIntHashMap<String> encodePositionMap) {
		final int endIndexMinus1 = endIndex - 1;
		int maxSyllableLength = maxSyllableLengthsMap.get(charSequence.charAt(endIndexMinus1));
		if (maxSyllableLength == 0){
			maxSyllableLength = 1;
		}
		//7: max syllable length
		int start = endIndex < maxSyllableLength ? 0 : endIndex - maxSyllableLength;
		for (int i = start; i < endIndex; i++) {
			 String substring = charSequence.substring(i, endIndex);
			 int position = encodePositionMap.get(substring);
			 if (position > 0){
				 return new Triple<String, Integer, Byte>(substring, i, ORDINARY);
			 }
		}
		
		//means a special character		
		String charString = charSequence.substring(endIndexMinus1, endIndex);
		int c = charString.codePointAt(0);
		if (c < 1024){
			return new Triple<String, Integer, Byte>("▼", endIndexMinus1, RARE1);
		}
		return new Triple<String, Integer, Byte>("▲", endIndexMinus1, RARE2);
	}
	
	
	private static final boolean[] isSeparationChar = new boolean[128];
	private static final String[] charWords = new String[128];
	static {
		char[] chars = { ' ', '@', '[', '\\', ']', '^', '_', '`', '!', '"', '#', 
				'%', '(', ')', '*','+', ',', '-', '/', ':', ';', '{', 
				'<', '|', '=', '}', '>', '~', '?', '\t', '\n'};
		for (char c : chars) {
			isSeparationChar[c] = true;
			charWords[c] = c + "";
		}
	}
	
	
	private Quadruple<String, Integer, String, Integer> decomposeToTwoWords(String segment) {
		final int length = segment.length();
		for (int i = length - 1; i >= 1; i--) {
			String w2 = segment.substring(i, length);
			int index2 = wordIndexMap.get(w2);
			if (index2 == 0)
				continue;
			String w1 = segment.substring(0, i);
			int index1 = wordIndexMap.get(w1);
			if (index1 != 0){
				return new Quadruple<String, Integer, String, Integer>(w1, index1, w2, index2);
			}
		}
		return null;
	}
	
//	private String createString(char value[], int startIndex, int length) {
//		char[] chars = new char[length];
//        System.arraycopy(value, startIndex, chars, 0, length);
//		return new String(chars);
//	}
	
	
	private Quadruple<String, Integer, String, Integer> decomposeToTwoWords(char[] chars, int start, int end) {
		int endMinus1 = end - 1;
		{
			String w2 = isSeparationChar(chars[endMinus1]) ? charWords[chars[endMinus1]] : new String(chars, endMinus1, 1);
			int index2 = wordIndexMap.get(w2);
			if (index2 == 0){
				return null;
			}
			String w1 = new String(chars, start, endMinus1 - start);
			int index1 = wordIndexMap.get(w1);
			if (index1 != 0){
				return new Quadruple<String, Integer, String, Integer>(w1, index1, w2, index2);
			}
		}
		
		
		int loopEnd = Math.max(end - 4, 1);
		for (int i = end - 2; i > loopEnd; i--) {
			String w2 = new String(chars, i, end - i);
			int index2 = wordIndexMap.get(w2);
			if (index2 == 0)
				continue;
			String w1 = new String(chars, start, i - start);
			int index1 = wordIndexMap.get(w1);
			if (index1 != 0){
				return new Quadruple<String, Integer, String, Integer>(w1, index1, w2, index2);
			}
		}
		
		return null;
	}
	
//	private Quadruple<String, Integer, String, Integer> decomposeToTwoWords(char[] chars, int start, int end) {
//		
//		
//		int loopEnd = Math.max(end - 3, 0);
//		for (int i = end - 1; i >= loopEnd; i--) {
//			String w2 = new String(chars, i, end - i);
//			int index2 = wordIndexMap.get(w2);
//			if (index2 == 0)
//				continue;
//			String w1 = new String(chars, start, i - start);
//			int index1 = wordIndexMap.get(w1);
//			if (index1 != 0){
//				return new Quadruple<String, Integer, String, Integer>(w1, index1, w2, index2);
//			}
//		}
//		
//		if (isSeparationChar(chars[start]) && start < loopEnd){
//			String w2 = new String(chars, start + 1, end - (start + 1));
//			int index2 = wordIndexMap.get(w2);
//			if (index2 == 0)
//				return null;
//			String w1 = charWords[chars[start]];
//			int index1 = wordIndexMap.get(w1);
//			if (index1 != 0){
//				return new Quadruple<String, Integer, String, Integer>(w1, index1, w2, index2);
//			}
//		}
//		
//		return null;
//	}
	
	public byte guessPOSIndex(String token) {
		char firstChar = token.charAt(0);
		byte posCase = firstChar >= 128 ? 2 : charToProbablePos[firstChar];
		switch (posCase) {
		//token.charAt(token.length() - 1): last char
		case 1: return CD;
		case 2: return token.charAt(token.length() - 1) == 's' ? NNS : NN;
		case 3: return token.charAt(token.length() - 1) == 's' ? NNPS_C : NNP_C;
		default: return token.charAt(token.length() - 1) == 's' ? NNS : NN;
		}
	}
	

	
	private boolean isSeparationChar(char c){
		return c < 128 && isSeparationChar[c];
	}
	
	
	
	private Token previousToken;
	public CompressionBits tokenizeToBits(String enText) {
		
		previousToken = Token.dummyFirstToken();
		String tempNextWord = null; //non-null when trying to tokenize a bigram but is not
		int tempNextWordIndex = 0;	//not zero if tempNextWord is not null and a word
		
		
		CompressionBits compressionBits = new CompressionBits(enText.length());
		BitSet bitSet = compressionBits.getBitSet();
		int offset = 0;
		
		final char[] chars = enText.toCharArray();
		final int charsLength = chars.length;
		int start = 0;
		
		StringBuilder charSequenceCache = new StringBuilder();
		for (int i = 0; i < charsLength; i++) {
			if (chars[i] >= 128 || isSeparationChar[chars[i]] == false){
				continue;
			}
			boolean isSpace = (chars[i] == ' ');
			if (start == i) {
				if (isSpace){
					if (charSequenceCache.length() > 0){
						charSequenceCache.append(' ');
					} else if (previousToken.isWord()){
						previousToken.setFollowedByASpace(true);
					} else {
						charSequenceCache.append(' ');
					}
				} else {
					offset = tokenizeSeparationChar(charSequenceCache, chars[i], bitSet, offset);					
				}
				start = i + 1;
				continue;
			}
			int length = i - start;
			
			String token = null;
			int wordIndex = 0;
			if (tempNextWord != null){
				token = tempNextWord;
				wordIndex = tempNextWordIndex;
				tempNextWord = null;
				tempNextWordIndex = 0;
			} else {
				token = new String(chars, start, length);
				wordIndex = wordIndexMap.get(token);
			}
			
			if (wordIndex > 0) {
				if (charSequenceCache.length() > 0) {
					offset = tokenizeCharSequence(charSequenceCache, bitSet, offset);
				}
				int j = i + 1;
				if (isSpace && j < charsLength && bigramStartSet.contains(wordIndex)){
					Pair<String, Integer> pair = getNextToken(chars, j);
					String nextToken = pair.getKey();
					int k = pair.getValue();
					int nextWordIndex = wordIndexMap.get(nextToken);
					if (nextWordIndex > 0) {
						int bmk = getBigramMapKey(wordIndex, nextWordIndex);
						int bigramIndex = bigramIndexMap.get(bmk);
						if (bigramIndex > 0){
							String bigram = wordArray[bigramIndex];
							offset = tokenizeWord(bigram, bigramIndex, k < charsLength, bitSet, offset);
							i = k;
							start = i + 1;
							continue;
						}
						if (nextToken.length() > 1){
							tempNextWord = nextToken;
							tempNextWordIndex = nextWordIndex;	
						}
					}
					
				} 
				
				offset = tokenizeWord(token, wordIndex, isSpace, bitSet, offset);
				if (isSpace == false) {
					offset = tokenizeSeparationChar(charSequenceCache, chars[i], bitSet, offset);
				}
			} else {
				Quadruple<String, Integer, String, Integer> twoWords = decomposeToTwoWords(chars, start, i);
				if (twoWords == null){
					charSequenceCache.append(token);
					charSequenceCache.append(chars[i]);
				} else {
					if (charSequenceCache.length() > 0) {
						offset = tokenizeCharSequence(charSequenceCache, bitSet, offset);
					}
					offset = tokenizeWord(twoWords.getFirst(), twoWords.getSecond(), false, bitSet, offset);
					offset = tokenizeWord(twoWords.getThird(), twoWords.getFourth(), isSpace, bitSet, offset);
					if (isSpace == false){
						offset = tokenizeSeparationChar(charSequenceCache, chars[i], bitSet, offset);
					}
				}
			}
			
			start = i + 1;
		}	//end for
		
		offset = tokenizeLastPossibleToken(chars, start, charsLength, charSequenceCache, bitSet, offset);
		
		if (previousToken.getTokenType() == Token.isWord && previousToken.isFollowedByASpace()){
			bitSet.set(offset);	
		}
		offset++;
		compressionBits.setOffset(offset);
		return compressionBits;
		 
	}
	
	
	

	private int tokenizeLastPossibleToken(char[] chars, int start, int charsLength, StringBuilder charSequenceCache, BitSet bitSet, int offset) {
		if (start < charsLength) {
			String token = new String(chars, start, charsLength - start);
			int wordIndex = wordIndexMap.get(token);
			if (wordIndex > 0) {
				if (charSequenceCache.length() > 0) {
					offset = tokenizeCharSequence(charSequenceCache, bitSet, offset);
				}
				Token wordToken = createWordToken(token, wordIndex);
				offset = addEncodingBits(previousToken, wordToken, bitSet, offset);
				previousToken = wordToken;
			} else {
				charSequenceCache.append(token);
				if (charSequenceCache.length() > 0) {
					offset = tokenizeCharSequence(charSequenceCache, bitSet, offset);
				}
			}
		} else if (charSequenceCache.length() > 0) {
			offset = tokenizeCharSequence(charSequenceCache, bitSet, offset);
		}
		return offset;
	}
	
	private int tokenizeSeparationChar(StringBuilder charSequenceCache, 
			char separationChar, BitSet bitSet, int offset) {
		String charToken = charWords[separationChar];
		int wordIndex = wordIndexMap.get(charToken);
		if (wordIndex > 0) {
			if (charSequenceCache.length() > 0) {
				offset = tokenizeCharSequence(charSequenceCache, bitSet, offset);
			}
			Token charWordToken = createWordToken(charToken, wordIndex);
			offset = addEncodingBits(previousToken, charWordToken, bitSet, offset);
			previousToken = charWordToken;
		} else {
			charSequenceCache.append(charToken);
		}
		return offset;
	}
	

	/**
	 * for testing
	 * @param enText
	 * @return
	 */
	public ArrayList<Token> tokenizeToTokensWithBigram(String enText){
		previousToken = Token.dummyFirstToken();
		ArrayList<Token> tokens = new ArrayList<Token>(3000);
		tokens.add(previousToken);
		
		final char[] chars = enText.toCharArray();
		final int charsLength = chars.length;
		int start = 0;
		
		StringBuilder charSequenceCache = new StringBuilder();
		for (int i = 0; i < charsLength; i++) {
			if (chars[i] >= 128 || isSeparationChar[chars[i]] == false){
				continue;
			}
			boolean isSpace = (chars[i] == ' ');
			if (start == i) {
				if (isSpace){
					if (charSequenceCache.length() > 0){
						charSequenceCache.append(' ');
					} else if (previousToken.isWord()){
						previousToken.setFollowedByASpace(true);
					} else {
						charSequenceCache.append(' ');
					}
				} else {
					String charToken = charWords[chars[i]];
					int wordIndex = wordIndexMap.get(charToken);
					if (wordIndex > 0) {
						if (charSequenceCache.length() > 0) {
							Token charSeqToken = createCharSequenceToken(charSequenceCache);
							tokens.add(charSeqToken);
						}
						Token charWordToken = createWordToken(charToken, wordIndex);
						tokens.add(charWordToken);
					} else {
						charSequenceCache.append(charToken);
					}
				}
				start = i + 1;
				continue;
			}
		
			String token = new String(chars, start, i - start);
			
			int wordIndex = wordIndexMap.get(token);
			if (wordIndex > 0) { 
				if (charSequenceCache.length() > 0) {
					Token charSeqToken = createCharSequenceToken(charSequenceCache);
					tokens.add(charSeqToken);
				}
				int j = i + 1;
				if (j < charsLength && bigramStartSet.contains(wordIndex)){
					Pair<String, Integer> pair = getNextToken(chars, j);
					String nextToken = pair.getKey();
					int k = pair.getValue();
					int nextTokenIndex = wordIndexMap.get(nextToken);
					if (nextTokenIndex > 0) { 
						
						String bigram = new String(chars, start, k - start);
						int bigramIndex = wordIndexMap.get(bigram);
						
						if (bigramIndex > 0){
							Token wordToken = createWordToken(bigram, bigramIndex);
							wordToken.setFollowedByASpace(chars[k] == ' ');
							tokens.add(wordToken);
							i = k;
							start = i + 1;
							continue;
						}
					}
				}
				
				Token wordToken = createWordToken(token, wordIndex);
				wordToken.setFollowedByASpace(isSpace);
				tokens.add(wordToken);
				if (isSpace == false) {
					String charToken = charWords[chars[i]];
					wordIndex = wordIndexMap.get(charToken);
					if (wordIndex > 0) {
						if (charSequenceCache.length() > 0) {
							Token charSeqToken = createCharSequenceToken(charSequenceCache);
							tokens.add(charSeqToken);
						}
						Token charWordToken = createWordToken(charToken, wordIndex);
						tokens.add(charWordToken);
					} else {
						charSequenceCache.append(charToken);
					}
				}
				
				
			} else {
				Quadruple<String, Integer, String, Integer> twoWords = decomposeToTwoWords(chars, start, i);
				if (twoWords == null){
					charSequenceCache.append(token);
					charSequenceCache.append(chars[i]);
				} else {
					if (charSequenceCache.length() > 0) {
						Token charSeqToken = createCharSequenceToken(charSequenceCache);
						tokens.add(charSeqToken);
					}
					Token token1 = createWordToken(twoWords.getFirst(), twoWords.getSecond());
					Token token2 = createWordToken(twoWords.getThird(), twoWords.getFourth());
					token2.setFollowedByASpace(isSpace);
					tokens.add(token1);
					tokens.add(token2);
					if (isSpace == false){
						String charToken = charWords[chars[i]];
						wordIndex = wordIndexMap.get(charToken);
						if (wordIndex > 0) {
							if (charSequenceCache.length() > 0) {
								Token charSeqToken = createCharSequenceToken(charSequenceCache);
								tokens.add(charSeqToken);
							}
							Token charWordToken = createWordToken(charToken, wordIndex);
							tokens.add(charWordToken);
						} else {
							charSequenceCache.append(charToken);
						}
					}
				}
			}
			start = i + 1;
		}	//end for
		
		if (start < charsLength) {
			String token = new String(chars, start, charsLength - start);
			int wordIndex = wordIndexMap.get(token);
			if (wordIndex > 0) {
				if (charSequenceCache.length() > 0) {
					Token charSeqToken = createCharSequenceToken(charSequenceCache);
					tokens.add(charSeqToken);
				}
				Token wordToken = createWordToken(token, wordIndex);
				tokens.add(wordToken);
			} else {
				charSequenceCache.append(token);
				if (charSequenceCache.length() > 0) {
					Token charSeqToken = createCharSequenceToken(charSequenceCache);
					tokens.add(charSeqToken);
				}
			}
		} else if (charSequenceCache.length() > 0) {
			Token charSeqToken = createCharSequenceToken(charSequenceCache);
			tokens.add(charSeqToken);
		}
		return tokens;
	}
	
	public ArrayList<Token> tokenizeToTokens(String text){
		
		ArrayList<Token> tokens = new ArrayList<Token>(text.length() / 3);
		tokens.add(Token.dummyFirstToken());
		
		final char[] chars = text.toCharArray();
		int start = 0;
		String token = null;
		
		
		StringBuilder charSequenceCache = new StringBuilder();
		
		final int charsLength = chars.length;
		for (int i = 0; i < charsLength; i++) {
			if (chars[i] >= 128 || isSeparationChar[chars[i]] == false){
				continue;
			}
			
			//reason: tokens.get(tokens.size() - 1) takes extra time in an intensive loop 
			Token tempWordToken = null;
			if (start < i) {
				token = text.substring(start, i);
				int wordIndex = wordIndexMap.get(token);
				if (wordIndex > 0) {
					if (charSequenceCache.length() > 0) {
						tokens.add(createCharSequenceToken(charSequenceCache));
					}
					tempWordToken = createWordToken(token, wordIndex);
					tokens.add(tempWordToken);
				} else {
					Quadruple<String, Integer, String, Integer> twoWords = decomposeToTwoWords(token);
					if (twoWords == null){
						charSequenceCache.append(token);
					} else {
						if (charSequenceCache.length() > 0) {
							tokens.add(createCharSequenceToken(charSequenceCache));
						}
						Token token1 = createWordToken(twoWords.getFirst(), twoWords.getSecond());
						Token token2 = createWordToken(twoWords.getThird(), twoWords.getFourth());
						tokens.add(token1);
						tempWordToken = token2;
						tokens.add(tempWordToken);
					}
				}
			}
			
			switch (chars[i]) {
			case ' ':
				if (tempWordToken == null) {
					charSequenceCache.append(' ');
				} else {
					tempWordToken.setFollowedByASpace(true);
					
				}
				break;
			default:
				token = charWords[chars[i]];
				//may also be a word, but is never composed of two words
				int wordIndex = wordIndexMap.get(token);
				if (wordIndex > 0) { 
					if (charSequenceCache.length() > 0) {
						tokens.add(createCharSequenceToken(charSequenceCache));
					}
					tempWordToken = createWordToken(token, wordIndex);
					tokens.add(tempWordToken);
				} else {
					charSequenceCache.append(token);
				}
				break;
			}
			
			start = i + 1;
		}
		
		
		if (start < charsLength) {
			token = text.substring(start);
			int wordIndex = wordIndexMap.get(text.substring(start));
			if (wordIndex > 0) { 
				if (charSequenceCache.length() > 0) {
					tokens.add(createCharSequenceToken(charSequenceCache));
				}
				tokens.add(createWordToken(token, wordIndex));
			} else {
				charSequenceCache.append(token);
				tokens.add(createCharSequenceToken(charSequenceCache));
			}
		} else if (charSequenceCache.length() > 0){
			tokens.add(createCharSequenceToken(charSequenceCache));
		}
		
		return tokens;
	}

	
	private Token createCharSequenceToken(StringBuilder charSequenceCache){
		String charSeq = charSequenceCache.toString();
		charSequenceCache.setLength(0);
		return new Token(charSeq, 
				Token.isCharSequence, Token.isNotFollowedBySpace, 0, guessPOSIndex(charSeq));
	}
	
	private Token createWordToken(String word, int wordIndex){
		return new Token(word, Token.isWord, 
							Token.isNotFollowedBySpace, wordIndex, startPosIndexArray[wordIndex], endPosIndexArray[wordIndex]);
	}
	
	
	
	
	
	/**
	 * thenAWord : correspond to 'tokenType' field of CompressionToken
	 * isFollowedByASpace: correspond to 'isFollowedByASpace' field of CompressionToken
	 *  
	 * @param thisPreTokenType
	 * 1: space, then a word
	 * 01: space, then not a word
	 * 001: not space, then a word
	 * 000: not space, then not a word
	 */
	protected int addWordPaddingBits(Token token1, Token token2, BitSet bitSet, int offset) {
		boolean followsASpace = token1.isFollowedByASpace();
		boolean followsAWord = token2.getTokenType() == Token.isWord;		
	
		if (followsASpace) {
			if (followsAWord){
				bitSet.set(offset++);
			} else {
				bitSet.set(offset + 1);
				offset += 2;
			}
		} else {
			if (followsAWord){
				bitSet.set(offset + 2);
				offset += 3;
			} else {
				offset += 3;
			}
		}
		return offset;
	}
	
	
	private int addPosTransitionBits(Token token1, Token token2, BitSet bitSet, int offset) {
		byte posIndex1 = token1.getEndPosIndex();
		byte posIndex2 = token2.getStartPosIndex();
		boolean[] bits = getPosTransitionBits(posIndex1, posIndex2);
		offset = BitSetUtils.addBits(bitSet, offset, bits);
		return offset;
	}
	
	
	private int addWordTokenBits(Token token2, BitSet bitSet, int offset) {
		byte posIndex = token2.getStartPosIndex();
		HuffmanIntegerInfo info = posesWordsHuffmanInfos.get(posIndex);
		boolean[] wordBits = info.getEncodeBits(token2.getWordIndex());
		offset = BitSetUtils.addBits(bitSet, offset, wordBits);
		return offset;
	}
	
	private int addCharSequenceTokenBits(Token token, BitSet bitSet, int offset) {
		ArrayList<boolean[]> bitsList = tokenizeByCharsInReverseOrder(token.getToken());
		for (int i = bitsList.size() - 1; i >= 0; i--){
			offset = BitSetUtils.addBits(bitSet, offset, bitsList.get(i));
		}
		return offset;
	}
	
	
	
	private int tokenizeCharSequence(StringBuilder charSequenceCache, BitSet bitSet, int offset){
		Token charSeqToken = createCharSequenceToken(charSequenceCache);
		offset = addEncodingBits(previousToken, charSeqToken, bitSet, offset);
		previousToken = charSeqToken;
		return offset;
	}
	
	
	private int tokenizeWord(String token, int wordIndex, Boolean followedBySpace, BitSet bitSet, int offset){
		Token wordToken = createWordToken(token, wordIndex);
		wordToken.setFollowedByASpace(followedBySpace);
		offset = addEncodingBits(previousToken, wordToken, bitSet, offset);
		previousToken = wordToken;
		return offset;
	}
	
	
//	private static int getBigramMapKey(int index1, int index2, boolean containsSpace){
//		return (index1 << 16) - index2 * 37 + (containsSpace ? 67108859 : 0);
//	}
	private static int getBigramMapKey(int index1, int index2){
		return (index1 << 16) + index2;
	}

	
	private Pair<String, Integer> getNextToken(char[] chars, int j){
		int k = j;
		for (; k < chars.length; k++){
			if (chars[k] == ' ') break;
		}
		String nextToken = new String(chars, j, k - j);
		return new Pair<String, Integer>(nextToken, k);
	}
	
	
	public int addEncodingBits(Token token1, Token token2, BitSet bitSet, int offset) {
		boolean token1IsWord = token1.getTokenType();
		boolean token2IsWord = token2.getTokenType();
		if (token1IsWord){
			offset = addWordPaddingBits(token1, token2, bitSet, offset);
		}
		if (token2IsWord){
			offset = addPosTransitionBits(token1, token2, bitSet, offset);
//			if (posesWordsHuffmanInfos.get(token2.getStartPosIndex()).getEncodePositionMap().size() <=1){
//				return offset;
//			}
//			switch (token2.getStartPosIndex()) {
//			case COMMA:
//			case EX:
//			case EX_C:
//			case RBS:
//			case TO_C:
//			case WP$:
//				return offset;
//			default:
//				break;
//			}
			offset = addWordTokenBits(token2, bitSet, offset);
		} else {
			offset = addCharSequenceTokenBits(token2, bitSet, offset);
		}
		return offset;
	}
	
	
	/**
	 * @return next posIndex
	 */
	private int decodeWord(BitSet bitSet, MutableInt offset, StringBuilder builder, int previousPosIndex){
		//decode transition pos
		HuffmanByteInfo nextPosInfo = posesHuffmanInfos.get(previousPosIndex);
		byte startPosIndex = nextPosInfo.getDecodedElement(bitSet, offset);
		
		//decode pos word
		HuffmanIntegerInfo nextWordInfo = posesWordsHuffmanInfos.get(startPosIndex);
		int wordIndex = nextWordInfo.getDecodedElement(bitSet, offset);
		builder.append(wordArray[wordIndex]);
//		return endPosIndexArray[wordIndex];
		return wordIndex;
	}
	
	/**
	 * @return next posIndex
	 */
	private byte decodeCharSequence(BitSet bitSet, MutableInt offset, StringBuilder builder){
		StringBuilder tempBuilder = new StringBuilder();
		
		char lastChar = ' ';
		do {
			String chars = charsHuffmanInfo.getDecodedElement(bitSet, offset);
			switch (chars) {
			case "▼":	//1024, extra 10
				char ch = (char) BitSetUtils.readIntFromBits(bitSet, offset, 10);
				tempBuilder.append(ch);
				continue;
			case "▲":	//65536, extra 16
				ch = (char) BitSetUtils.readIntFromBits(bitSet, offset, 16);
				tempBuilder.append(ch);
				continue;
			default:
				break;
			}
			tempBuilder.append(chars);
			lastChar = chars.charAt(chars.length() - 1);
		} while (lastChar != '\0');
		String charSeq = tempBuilder.substring(0, tempBuilder.length() - 1);
		builder.append(charSeq);
		return (byte) (-guessPOSIndex(charSeq));
	}
	
	public int decodeAfterCharSequence(BitSet bitSet, MutableInt offset, StringBuilder builder, int previousPosIndex){
		return decodeWord(bitSet, offset, builder, -previousPosIndex);
	}
	
	/** @param thisPreTokenType
	 * 1: space, then a word
	 * 01: space, then not a word
	 * 001: not space, then a word
	 * 000: not space, then not a word
	 */
	public int decodeAfterWord(BitSet bitSet, MutableInt offset, StringBuilder builder, int previousPosIndex){
		int index = offset.getInteger();
		if (bitSet.get(index++)){
			builder.append(' ');
			offset.add(1);
			/**1: space, then a word*/
			return decodeWord(bitSet, offset, builder, previousPosIndex);
		}
		
		if (bitSet.get(index++)){
			/**01: space, then not a word*/
			builder.append(' ');
			offset.add(2);
			return decodeCharSequence(bitSet, offset, builder);
		}
		
		if (bitSet.get(index++)){
			/**001: not space, then a word*/
			offset.add(3);
			return decodeWord(bitSet, offset, builder, previousPosIndex);
		} else {
			/**000: not space, then not a word*/
			offset.add(3);
			return decodeCharSequence(bitSet, offset, builder);
		}
		
	}
	
	private EnTextCompressionInfo() {
		
	}

	
	/**
	 * see the create() method
	 */
	public static void main(String[] args) {
//		recreateCompressionInfo();
//		adjustWordInfoMap();
		
		
	}


	
	
}

