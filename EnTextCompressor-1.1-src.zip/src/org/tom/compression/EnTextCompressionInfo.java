package org.tom.compression;

import gnu.trove.map.hash.TCharByteHashMap;
import gnu.trove.map.hash.TObjectByteHashMap;
import gnu.trove.map.hash.TObjectIntHashMap;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;

import org.tom.common.BitSet;
import org.tom.common.ComparablePair;
import org.tom.common.Frequencies;
import org.tom.common.MutableInt;
import org.tom.common.Quadruple;
import org.tom.common.Triple;
import org.tom.common.WordInfo;
import org.tom.compression.Token;
import org.tom.compression.HuffmanByteInfo;
import org.tom.compression.HuffmanInfo;
import org.tom.compression.HuffmanIntegerInfo;


import org.tom.compression.Token.Tokens;
import org.tom.utils.BitSetUtils;
import org.tom.utils.ObjectSerializer;



/**
 * one HashMap<String, Integer> enCharToPositionMap,
 * one BinaryTree<String> enCharDecodeTree,
 * 
 * one HashMap<String, WordType> 
 * 
 * @author Tom3_Lin
 */
public class EnTextCompressionInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	//key: words; value: word indices
	private TObjectIntHashMap<String> wordIndexMap;
	
	//key: word indices; value: words;
	private String[] wordArray;

	//key: word indices; value: pos indices;
	private byte[] wordPosIndexArray;
	
	//about pos transition; corresponding to different poses; element: pos indices
	private ArrayList<HuffmanByteInfo> posesHuffmanInfos;
	//corresponding to words of different poses; element: word indices
	private ArrayList<HuffmanIntegerInfo> posesWordsHuffmanInfos;

	//for encoding non-word char sequences
	private HuffmanInfo<String> charsHuffmanInfo;

	//used to speed up checking 2-4 grams 
	private byte[] wordNGramEndInfo;
	
	private TCharByteHashMap maxSyllableLengthsMap;
	
	
	////////////////////////////////////////////////////

	/**
	 * @return the wordIndexMap
	 */
	public TObjectIntHashMap<String> getWordIndexMap() {
		return wordIndexMap;
	}

	/**
	 * @param wordIndexMap the wordIndexMap to set
	 */
	public void setWordIndexMap(TObjectIntHashMap<String> wordIndexMap) {
		this.wordIndexMap = wordIndexMap;
	}

	/**
	 * @return the wordArray
	 */
	public String[] getWordArray() {
		return wordArray;
	}

	/**
	 * @param wordArray the wordArray to set
	 */
	public void setWordArray(String[] wordArray) {
		this.wordArray = wordArray;
	}

	/**
	 * @return the wordPosIndexArray
	 */
	public byte[] getWordPosIndexArray() {
		return wordPosIndexArray;
	}

	/**
	 * @param wordPosIndexArray the wordPosIndexArray to set
	 */
	public void setWordPosIndexArray(byte[] wordPosIndexArray) {
		this.wordPosIndexArray = wordPosIndexArray;
	}

	/**
	 * @return the posesHuffmanInfos
	 */
	public ArrayList<HuffmanByteInfo> getPosesHuffmanInfos() {
		return posesHuffmanInfos;
	}

	/**
	 * @param posesHuffmanInfos the posesHuffmanInfos to set
	 */
	public void setPosesHuffmanInfos(ArrayList<HuffmanByteInfo> posesHuffmanInfos) {
		this.posesHuffmanInfos = posesHuffmanInfos;
	}

	/**
	 * @return the posesWordsHuffmanInfos
	 */
	public ArrayList<HuffmanIntegerInfo> getPosesWordsHuffmanInfos() {
		return posesWordsHuffmanInfos;
	}

	/**
	 * @param posesWordsHuffmanInfos the posesWordsHuffmanInfos to set
	 */
	public void setPosesWordsHuffmanInfos(ArrayList<HuffmanIntegerInfo> posesWordsHuffmanInfos) {
		this.posesWordsHuffmanInfos = posesWordsHuffmanInfos;
	}

	/**
	 * @return the charsHuffmanInfo
	 */
	public HuffmanInfo<String> getCharsHuffmanInfo() {
		return charsHuffmanInfo;
	}

	/**
	 * @param charsHuffmanInfo the charsHuffmanInfo to set
	 */
	public void setCharsHuffmanInfo(HuffmanInfo<String> charsHuffmanInfo) {
		this.charsHuffmanInfo = charsHuffmanInfo;
	}

	
	
	/**
	 * @return the wordNGramEndInfo
	 */
	public byte[] getWordNGramEndInfo() {
		return wordNGramEndInfo;
	}

	/**
	 * @param wordNGramEndInfo the wordNGramEndInfo to set
	 */
	public void setWordNGramEndInfo(byte[] wordNGramEndInfo) {
		this.wordNGramEndInfo = wordNGramEndInfo;
	}
	
	/**
	 * @return the maxSyllableLengthsMap
	 */
	public TCharByteHashMap getMaxSyllableLengthsMap() {
		return maxSyllableLengthsMap;
	}

	/**
	 * @param maxSyllableLengthsMap the maxSyllableLengthsMap to set
	 */
	public void setMaxSyllableLengthsMap(TCharByteHashMap maxSyllableLengthsMap) {
		this.maxSyllableLengthsMap = maxSyllableLengthsMap;
	}

	////////////////////////////////////////////////////
	
	/**
	 * key: pos
	 * value: index 
	 */
	private static TObjectByteHashMap<String> createPosIndexMap(HashMap<String, WordInfo> wordInfoMap) {
		Iterator<Entry<String, WordInfo>> iterator = wordInfoMap.entrySet().iterator();
		
		HashSet<String> posSet = new HashSet<String>();
		while (iterator.hasNext()){
			Entry<String, WordInfo> entry = iterator.next();
			posSet.add(entry.getValue().getPos());
		}
		TObjectByteHashMap<String> posIndexMap = new TObjectByteHashMap<String>();
		
		ArrayList<String> posList = new ArrayList<String>(posSet);
		Collections.sort(posList);
		byte index = 1;
		for(String pos : posList){
			posIndexMap.put(pos, index++);
		}
		return posIndexMap;
	}
	
	private static ArrayList<Frequencies<Byte>> createNextPosFrequencies(Frequencies<String> posBigramFrequencies, 
			TObjectByteHashMap<String> posIndexMap) {
		
		ArrayList<Frequencies<Byte>> posToPosFrequencies = new ArrayList<Frequencies<Byte>>(posIndexMap.size() + 1);
		posToPosFrequencies.add(null);
		for (int i = 0; i < posIndexMap.size(); i++) {
			posToPosFrequencies.add(new Frequencies<Byte>());
		}
		
		Iterator<Entry<String, Long>> iterator = posBigramFrequencies.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<String, Long> entry = iterator.next();
			
			String posBigram = entry.getKey();
			String[] twoPoses = posBigram.split("-");
			byte firstPosIndex = posIndexMap.get(twoPoses[0]);
			byte secondPosIndex = posIndexMap.get(twoPoses[1]);
			Frequencies<Byte> theFreqToAdd = posToPosFrequencies.get(firstPosIndex);
			theFreqToAdd.addFrequency(secondPosIndex, entry.getValue());
		}
		return posToPosFrequencies;
	}
	
	private static ArrayList<Frequencies<Integer>> getPosWordsFrequencies(byte[] wordPosIndexArray, String[] wordArray, HashMap<String, WordInfo> wordInfoMap, final int numPoses) {
		
		ArrayList<Frequencies<Integer>> posWordsFrequencies = new ArrayList<Frequencies<Integer>>(numPoses + 1);
		posWordsFrequencies.add(null);
		for (int i = 0; i < numPoses; i++) {
			posWordsFrequencies.add(new Frequencies<Integer>());
		}
		
		for (int i = 1; i < wordPosIndexArray.length; i++) {
			byte posIndex = wordPosIndexArray[i];
			Frequencies<Integer> freqsToAdd = posWordsFrequencies.get(posIndex);
			String word = wordArray[i];
			long wordFreq = wordInfoMap.get(word).getFrequency();
			freqsToAdd.addFrequency(i, wordFreq);
		}
		return posWordsFrequencies;
	}
	
	private static ArrayList<Frequencies<Integer>> getPosWordsFrequencies(
			Frequencies<Tokens> recountedFrequencies, EnTextCompressionInfo enTextCompressionInfo) {
		
		TObjectIntHashMap<String> wordIndexMap = enTextCompressionInfo.getWordIndexMap();
		byte[] wordPosIndexArray = enTextCompressionInfo.getWordPosIndexArray();
		int numPoses = enTextCompressionInfo.getPosesHuffmanInfos().size() - 1;
		ArrayList<Frequencies<Integer>> posWordsFrequencies = new ArrayList<Frequencies<Integer>>(numPoses + 1);
		posWordsFrequencies.add(null);
		for (int i = 0; i < numPoses; i++) {
			posWordsFrequencies.add(new Frequencies<Integer>());
		}
		
		Iterator<Entry<Tokens, Long>> iterator = recountedFrequencies.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<Tokens, Long> entry = iterator.next();
			Tokens key = entry.getKey();
			String firstWord = key.get(0).getToken();
			int firstWordIndex = wordIndexMap.get(firstWord);
			if (firstWordIndex <= 0){
				System.out.println("Ignore this: firstWordIndex = " + firstWordIndex + ", firstWord = " + firstWord);
				continue;
			}
			
			long wordFreq = entry.getValue();
			//index for pos words frequencies
			byte startPosIndex = wordPosIndexArray[firstWordIndex];
			
			String wholePhrase = key.toString();
			int wholePhraseIndex = wordIndexMap.get(wholePhrase);
			if (wholePhraseIndex <= 0){
				throw new Error("Bugs had occurred");
			}
			
			Frequencies<Integer> freqsToAdd = posWordsFrequencies.get(startPosIndex);
			freqsToAdd.addFrequency(wholePhraseIndex, wordFreq);
		}
		
		
		return posWordsFrequencies;
	}
	
	
	private static final byte[] charToProbablePos = setCharToProbablePos();
	private static byte[] setCharToProbablePos() {
		byte[] bs = new byte[128];
		for (char c = '0'; c <= '9'; c++) { bs[c] = 1;} 
		for (char c = 'a'; c <= 'z'; c++) { bs[c] = 2;}
		for (char c = 'A'; c <= 'Z'; c++) {	bs[c] = 3;}
		bs[' '] = 4;
		return bs;
	}
	
	private static final byte CD = 3;
	private static final byte NNS = 24;
	private static final byte NN = 20;
	private static final byte NNPS_C = 22;
	private static final byte NNP_C = 23;
	
	//one-word pos tags
	private static final byte COMMA = 5; 	//,
	private static final byte EX_C = 9;		//There
	private static final byte RBS = 39;		//most
	private static final byte EX = 8;		//there
	private static final byte TO_C = 43;	//To
	private static final byte WP$ = 59;		//whose
	
	
	

	protected static void recreateCompressionInfo() {
		EnTextCompressionInfo enTextCompressionInfo = 
				ObjectSerializer.deserialize("D:/Temp/enTextCompressionInfo.ser - old.gz", true);
		Frequencies<String> enWordPhraseFrequencies = 
				ObjectSerializer.deserialize("D:/Temp/enWordPhraseFrequencies.ser.gz", true);
		
		byte[] wordPosIndexArray = enTextCompressionInfo.getWordPosIndexArray();

		final int numPoses = enTextCompressionInfo.getPosesHuffmanInfos().size() - 1;
		
		System.out.println("enWordPhraseFrequencies.size() = " + enWordPhraseFrequencies.size());

		String[] oldWordArray = enTextCompressionInfo.getWordArray();
		
		Frequencies<Tokens> recountedFrequencies = 
				ObjectSerializer.deserialize("D:/Temp/recountedFrequencies.ser - Copy.gz", true);
		

		Iterator<Entry<Tokens, Long>> iterator = recountedFrequencies.entrySet().iterator();
	
		String[] wordArray = new String[recountedFrequencies.size() + 1];
		System.arraycopy(oldWordArray, 1, wordArray, 1, oldWordArray.length - 1);
		TObjectIntHashMap<String> wordIndexMap = new TObjectIntHashMap<String>(wordArray.length);
		
//		System.out.println("wordIndexMap.size() = " + enTextCompressionInfo.getWordIndexMap().size());
//		System.out.println("System.exit(0) at EnTextCompressionInfo.recreateCompressionInfo()");
//		System.exit(0);

		wordIndexMap.putAll(enTextCompressionInfo.getWordIndexMap());

		int index = oldWordArray.length;
		while (iterator.hasNext()){
			Entry<Tokens, Long> entry = iterator.next();
			Tokens key = entry.getKey();
			if (key.size() == 1){
				continue;
			}
			String keyString = key.toString();
			wordArray[index] = keyString;
			wordIndexMap.put(keyString, index);
			index++;
		}
		
		enTextCompressionInfo.setWordArray(wordArray);
		enTextCompressionInfo.setWordIndexMap(wordIndexMap);
		
		//re-create enTextCompressionInfo.getPosesWordsHuffmanInfos();
		
		ArrayList<Frequencies<Integer>> posWordsFrequencies = 
				getPosWordsFrequencies(recountedFrequencies, enTextCompressionInfo);
		ArrayList<HuffmanIntegerInfo> posesWordsHuffmanInfos = new ArrayList<HuffmanIntegerInfo>(numPoses + 1);
		posesWordsHuffmanInfos.add(null);
		for (int i = 1; i <= numPoses; i++) {
			Frequencies<Integer> frequencies = posWordsFrequencies.get(i); 
			HuffmanIntegerInfo info = HuffmanIntegerInfo.create(frequencies);
			posesWordsHuffmanInfos.add(info);
		}
		
		byte[] wordNGramEndInfo = ObjectSerializer.deserialize("D:/Temp/wordNGramEndInfo.ser.gz", true);
		
		EnTextCompressionInfo enCompressionInfo = new EnTextCompressionInfo();
		
		enCompressionInfo.wordIndexMap = wordIndexMap;
		enCompressionInfo.wordArray = wordArray;
		enCompressionInfo.wordPosIndexArray = wordPosIndexArray;
		enCompressionInfo.posesHuffmanInfos = enTextCompressionInfo.getPosesHuffmanInfos();
		enCompressionInfo.posesWordsHuffmanInfos = posesWordsHuffmanInfos;
		enCompressionInfo.charsHuffmanInfo = enTextCompressionInfo.getCharsHuffmanInfo();
		enCompressionInfo.wordNGramEndInfo = wordNGramEndInfo;
		ObjectSerializer.serialize(enCompressionInfo, "D:/Temp/enTextCompressionInfo.ser.gz", true);
		
		System.exit(0);
	}
	
	protected static void manuallyAdjustSomeEntries(HashMap<String, WordInfo> wordInfoMap) {
		wordInfoMap.remove("9E9E9");
		wordInfoMap.remove("CiconiiformesFamily");
		wordInfoMap.remove("PelecaniformesFamily");
		wordInfoMap.remove("CoraciiformesFamily");
		wordInfoMap.remove("GruiformesFamily");
		wordInfoMap.remove("FalconiformesFamily");
		
		wordInfoMap.put("ly", new WordInfo("RB", 320000L));
		wordInfoMap.get("ing").setPos("VBG");
		
	}
	
	protected static EnTextCompressionInfo create(PreTrainedCompressionData data) {
		
		HashMap<String, WordInfo> wordInfoMap = data.wordInfoMap;
		Frequencies<String> topCharsFrequencies = 
				ObjectSerializer.deserialize( "D:/Temp/topCharsFrequencies.ser.gz", true);
		manuallyAdjustSomeEntries(wordInfoMap);
		
		
		//a temporary map; pos Strings are no longer used afterwards
		/**
		 * {EX_C=9,WP_C=60,CD_C=4,OTHER_C=28,WRB_C=62,CC=1,PERIOD=29,IN=10,
		 * CD=3,JJ=12,VB=44,VBG_C=48,RBS=39,RBR=37,JJ_C=17,RBR_C=38,NNPS_C=22,
		 * PRP_C=34,VBP_C=52,JJR_C=14,NN=20,NNS_C=25,PRP$=32,WRB=61,TO=42,COMMA=5,
		 * VBN=49,VBN_C=50,CC_C=2,PRP=31,WDT=56,VBZ_C=54,PRP$_C=33,MD=18,VB_C=55,
		 * TO_C=43,VBZ=53,RB_C=40,VBP=51,RP=41,EX=8,VBG=47,VBD=45,OTHER=27,DT_C=7,
		 * RB=36,NN_C=26,MD_C=19,VBD_C=46,NNS=24,NNP=21,WP$=59,DT=6,POS=30,WDT_C=57,
		 * WP=58,IN_C=11,JJS_C=16,JJS=15,JJR=13,NNP_C=23,PU=35}
		 */
		TObjectByteHashMap<String> posIndexMap = createPosIndexMap(wordInfoMap);
		
		
		final int numWords = wordInfoMap.size();
		final int numPoses = posIndexMap.size();
		
		TObjectIntHashMap<String> wordIndexMap = new TObjectIntHashMap<String>(numWords);
		String[] wordArray = new String[numWords + 1];
		byte[] wordPosIndexArray = new byte[numWords + 1];
		
		ArrayList<ComparablePair<String, Integer>> wordIndexPairs = new ArrayList<>(numWords + 1);
		
		Iterator<Entry<String, WordInfo>> iterator = wordInfoMap.entrySet().iterator();
		int index = 1;
		while (iterator.hasNext()){
			Entry<String, WordInfo> entry = iterator.next();
			String word = entry.getKey();
			String pos = entry.getValue().getPos();
			byte posIndex = posIndexMap.get(pos);
			wordArray[index] = word;
			wordPosIndexArray[index] = posIndex;
			wordIndexMap.put(word, index);
			wordIndexPairs.add(new ComparablePair<String, Integer>(word, index));
			index++;
		}
		
		Collections.sort(wordIndexPairs, ComparablePair.ascendingValueComparator());

		Frequencies<String> posBigramFrequencies = ObjectSerializer.deserialize("D:/Temp/posBigramFrequencies.ser.gz", true);
		ArrayList<Frequencies<Byte>> posToPosFrequencies = createNextPosFrequencies(posBigramFrequencies, posIndexMap);
		
		ArrayList<HuffmanByteInfo> posesHuffmanInfos = new ArrayList<HuffmanByteInfo>(numPoses + 1);
		posesHuffmanInfos.add(null);
		for (int posIndex = 1; posIndex <= numPoses; posIndex++){  
			Frequencies<Byte> bigramPosFreq = posToPosFrequencies.get(posIndex);
			HuffmanByteInfo huffmanInfo = HuffmanByteInfo.create(bigramPosFreq);
			posesHuffmanInfos.add(huffmanInfo);
		}
		
		ArrayList<Frequencies<Integer>> posWordsFrequencies = getPosWordsFrequencies(wordPosIndexArray, wordArray, wordInfoMap, numPoses);
		
		ArrayList<HuffmanIntegerInfo> posesWordsHuffmanInfos = new ArrayList<HuffmanIntegerInfo>(numPoses + 1);
		posesWordsHuffmanInfos.add(null);
		for (int i = 1; i <= numPoses; i++) {
			Frequencies<Integer> frequencies = posWordsFrequencies.get(i); 
			HuffmanIntegerInfo info = HuffmanIntegerInfo.create(frequencies);
			posesWordsHuffmanInfos.add(info);
		}
		
		topCharsFrequencies.remove("★");
		TCharByteHashMap maxSyllableLengthsMap = createMaxSyllableLengths(topCharsFrequencies);
		
		HuffmanInfo<String> charsHuffmanInfo = HuffmanInfo.create(topCharsFrequencies);
		
		
		EnTextCompressionInfo enCompressionInfo = new EnTextCompressionInfo();
		
		enCompressionInfo.wordIndexMap = wordIndexMap;
		enCompressionInfo.wordArray = wordArray;
		enCompressionInfo.wordPosIndexArray = wordPosIndexArray;
		enCompressionInfo.posesHuffmanInfos = posesHuffmanInfos;
		enCompressionInfo.posesWordsHuffmanInfos = posesWordsHuffmanInfos;
		enCompressionInfo.charsHuffmanInfo = charsHuffmanInfo;
		enCompressionInfo.setMaxSyllableLengthsMap(maxSyllableLengthsMap);
		
//		ObjectSerializer.serialize(enCompressionInfo, "D:/Temp/enTextCompressionInfo.ser.gz", true);
		return enCompressionInfo;
	}
	
	protected static TCharByteHashMap createMaxSyllableLengths(Frequencies<String> topCharsFrequencies) {
		TCharByteHashMap map = new TCharByteHashMap();
		Iterator<Entry<String, Long>> iterator = topCharsFrequencies.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<String, Long> entry = iterator.next();
			String key = entry.getKey();
			
			char lastChar = key.charAt(key.length() - 1);
			int bt = map.get(lastChar);
			if (bt < key.length()){
				map.put(lastChar, (byte) key.length());
			}
		}
		return map;
	}
	
	
	
	public byte getPosIndex(int wordIndex) {
		return wordPosIndexArray[wordIndex];
	}

	public boolean[] getPosTransitionBits(byte posIndex1, byte posIndex2){
		HuffmanByteInfo info = posesHuffmanInfos.get(posIndex1);
		return info.getEncodeBits(posIndex2);
	}
	
	
	
	
	private static final byte ORDINARY = 0;
	private static final byte RARE1 = 1;
	private static final byte RARE2 = 2;
	
	/**
	 * save time for calling 'Collections.reverse(bitsList);'
	 * @param charSequence
	 */
	public ArrayList<boolean[]> tokenizeByCharsInReverseOrder(String charSequence) {
		charSequence = charSequence + '\0';
		int endIndex = charSequence.length();
		
		TObjectIntHashMap<String> encodePositionMap = charsHuffmanInfo.getEncodePositionMap();
		ArrayList<boolean[]> bitsList = new ArrayList<boolean[]>();
		while (endIndex > 0) {
			Triple<String, Integer, Byte> triple = getLongestSyllable(charSequence, endIndex, encodePositionMap);
			String chars = triple.getFirst();
			endIndex = triple.getSecond();
			switch (triple.getThird()){
				case ORDINARY: break;
				case RARE1: //10 bits
					char codePoint = charSequence.charAt(endIndex);
					bitsList.add(BitSetUtils.toBits(codePoint, 10));break;
				case RARE2: //16 bits
					codePoint = charSequence.charAt(endIndex);
					bitsList.add(BitSetUtils.toBits(codePoint, 16));break;
			}
			bitsList.add(charsHuffmanInfo.getEncodeBits(chars));
		}
		return bitsList;
	}
	

	/**@param charSequence
	 * @param endIndex
	 * @return triple
	 * first: char or syllable 
	 * second: end index of String 'first'
	 * Byte: a rare character or not: 0, 1, 2, or 3
	 */
	protected Triple<String, Integer, Byte> getLongestSyllable(String charSequence, int endIndex, 
			TObjectIntHashMap<String> encodePositionMap) {
		final int endIndexMinus1 = endIndex - 1;
		int maxSyllableLength = maxSyllableLengthsMap.get(charSequence.charAt(endIndexMinus1));
		if (maxSyllableLength == 0){
			maxSyllableLength = 1;
		}
		//7: max syllable length
		int start = endIndex < maxSyllableLength ? 0 : endIndex - maxSyllableLength;
		for (int i = start; i < endIndex; i++) {
			 String substring = charSequence.substring(i, endIndex);
			 int position = encodePositionMap.get(substring);
			 if (position > 0){
				 return new Triple<String, Integer, Byte>(substring, i, ORDINARY);
			 }
		}
		
		//means a special character		
		String charString = charSequence.substring(endIndexMinus1, endIndex);
		int c = charString.codePointAt(0);
		if (c < 1024){
			return new Triple<String, Integer, Byte>("▼", endIndexMinus1, RARE1);
		}
		return new Triple<String, Integer, Byte>("▲", endIndexMinus1, RARE2);
	}
	
	
	private static final boolean[] isSeparationChar = new boolean[128];
	private static final String[] charWords = new String[128];
	static {
		
		char[] chars = { ' ', '@', '[', '\\', ']', '^', '_', '`', '!', '"', '#', 
				'%', '(', ')', '*','+', ',', '-', '/', ':', ';', '{', 
				'<', '|', '=', '}', '>', '~', '?', '\t', '\n'};
		for (char c : chars) {
			isSeparationChar[c] = true;
			charWords[c] = c + "";
		}
	}
	
	
	private Quadruple<String, Integer, String, Integer> decomposeToTwoWords(String segment) {
		final int length = segment.length();
		for (int i = length - 1; i >= 1; i--) {
			String w2 = segment.substring(i, length);
			int index2 = wordIndexMap.get(w2);
			if (index2 == 0)
				continue;
			String w1 = segment.substring(0, i);
			int index1 = wordIndexMap.get(w1);
			if (index1 != 0){
				return new Quadruple<String, Integer, String, Integer>(w1, index1, w2, index2);
			}
		}
		return null;
	}
	
	private Quadruple<String, Integer, String, Integer> decomposeToTwoWords(char[] chars, int start, int end) {
		int loopEnd = Math.max(end - 3, 0);
		
		for (int i = end - 1; i >= loopEnd; i--) {
			String w2 = new String(chars, i, end - i);
			int index2 = wordIndexMap.get(w2);
			if (index2 == 0)
				continue;
			String w1 = new String(chars, start, i - start);
			int index1 = wordIndexMap.get(w1);
			if (index1 != 0){
				return new Quadruple<String, Integer, String, Integer>(w1, index1, w2, index2);
			}
		}
		return null;
	}
	
	public byte guessPOSIndex(String token) {
		char firstChar = token.charAt(0);
		byte posCase = firstChar >= 128 ? 2 : charToProbablePos[firstChar];
		switch (posCase) {
		//token.charAt(token.length() - 1): last char
		case 1: return CD;
		case 2: return token.charAt(token.length() - 1) == 's' ? NNS : NN;
		case 3: return token.charAt(token.length() - 1) == 's' ? NNPS_C : NNP_C;
		default: return token.charAt(token.length() - 1) == 's' ? NNS : NN;
		}
	}
	
	private int offset;
	
	public CompressionBits tokenizeToBits(String enText) {
		Token previousToken = Token.dummyFirstToken();
		
		CompressionBits compressionBits = new CompressionBits(enText.length());
		BitSet bitSet = compressionBits.getBitSet();
		offset = compressionBits.getOffset();
		
		final char[] chars = enText.toCharArray();
		int start = 0;
		String token = null;
		
		StringBuilder charSequenceCache = new StringBuilder();
		
		final int charsLength = chars.length;
		for (int i = 0; i < charsLength; i++) {
			if (chars[i] >= 128 || isSeparationChar[chars[i]] == false){
				continue;
			}
			
			//reason: tokens.get(tokens.size() - 1) takes extra time in an intensive loop 
			Token tempWordToken = null;
			if (start < i) {
				token = new String(chars, start, i - start);
				
				int wordIndex = wordIndexMap.get(token);
				if (wordIndex > 0) { 
					if (charSequenceCache.length() > 0) {
						previousToken = addCharSequence(charSequenceCache, previousToken, bitSet);
					}
					tempWordToken = new Token(token, Token.isWord, 
							Token.isNotFollowedBySpace, wordIndex, wordPosIndexArray[wordIndex]);
				} else {
					Quadruple<String, Integer, String, Integer> twoWords = decomposeToTwoWords(chars, start, i);
					if (twoWords == null){
						charSequenceCache.append(token);
					} else {
						if (charSequenceCache.length() > 0) {
							previousToken = addCharSequence(charSequenceCache, previousToken, bitSet);
						}
						Token token1 = new Token(twoWords.getFirst(), Token.isWord, Token.isNotFollowedBySpace, twoWords.getSecond(), wordPosIndexArray[twoWords.getSecond()]);
						addEncodingBits(previousToken, token1, bitSet);
						previousToken = token1;
						tempWordToken = new Token(twoWords.getThird(), Token.isWord, Token.isNotFollowedBySpace, twoWords.getFourth(), wordPosIndexArray[twoWords.getFourth()]);
					}
				}
			}
			
			
			switch (chars[i]) {
			case ' ':
				if (tempWordToken == null) {
					charSequenceCache.append(' ');
				} else {
					tempWordToken.setFollowedByASpace(true);
					addEncodingBits(previousToken, tempWordToken, bitSet);
					previousToken = tempWordToken;
				}
				break;
			default:
				token = charWords[chars[i]];
				//may also be a word, but is never composed of two words
				if (tempWordToken != null){
					addEncodingBits(previousToken, tempWordToken, bitSet);
					previousToken = tempWordToken;
				}
				
				int wordIndex = wordIndexMap.get(token);
				if (wordIndex > 0) { 
					if (charSequenceCache.length() > 0) {
						previousToken = addCharSequence(charSequenceCache, previousToken, bitSet);
					}
					Token charWordToken = new Token(token, Token.isWord, Token.isNotFollowedBySpace, wordIndex, wordPosIndexArray[wordIndex]);
					addEncodingBits(previousToken, charWordToken, bitSet);
					previousToken = charWordToken;
				} else {
					charSequenceCache.append(token);
				}
				break;
			}
			start = i + 1;
		}
		
		// add the last token
		if (start < charsLength) {
			token = new String(chars, start, charsLength - start);
			int wordIndex = wordIndexMap.get(token);
			if (wordIndex > 0) { 
				if (charSequenceCache.length() > 0) {
					previousToken = addCharSequence(charSequenceCache, previousToken, bitSet);
				}
				
				Token wordToken = new Token(token, Token.isWord, 
						Token.isNotFollowedBySpace, wordIndex, wordPosIndexArray[wordIndex]);
				addEncodingBits(previousToken, wordToken, bitSet);
				previousToken = wordToken;
			} else {
				charSequenceCache.append(token);
				previousToken = addCharSequence(charSequenceCache, previousToken, bitSet);
			}
		} else if (charSequenceCache.length() > 0){
			previousToken = addCharSequence(charSequenceCache, previousToken, bitSet);
		}
		
		//////////////
	
		if (previousToken.getTokenType() == Token.isWord && previousToken.isFollowedByASpace()){
			bitSet.set(offset);	
		}
		offset++;
		compressionBits.setOffset(offset);
		
		return compressionBits;
	}
	
public ArrayList<Token> tokenizeBySeparators(String text) {
		
		ArrayList<Token> tokens = new ArrayList<>(text.length() / 3);
		tokens.add(Token.dummyFirstToken());
		
		final char[] chars = text.toCharArray();
		int start = 0;
		String token = null;
		
		StringBuilder charSequenceCache = new StringBuilder();
		
		final int charsLength = chars.length;
		for (int i = 0; i < charsLength; i++) {
			if (chars[i] >= 128 || isSeparationChar[chars[i]] == false){
				continue;
			}
			
			//reason: tokens.get(tokens.size() - 1) takes extra time in an intensive loop 
			Token tempWordToken = null;
			if (start < i) {
				token = text.substring(start, i);
				int wordIndex = wordIndexMap.get(token);
				if (wordIndex > 0) { 
					if (charSequenceCache.length() > 0) {
						String charSeq = charSequenceCache.toString();
						tokens.add(new Token(charSeq, 
								Token.isCharSequence, Token.isNotFollowedBySpace, 0, guessPOSIndex(charSeq)));
						charSequenceCache.setLength(0);
					}
					
					tempWordToken = new Token(token, Token.isWord, 
							Token.isNotFollowedBySpace, wordIndex, wordPosIndexArray[wordIndex]);
					tokens.add(tempWordToken);
				} else {
					Quadruple<String, Integer, String, Integer> twoWords = decomposeToTwoWords(token);
					if (twoWords == null){
						charSequenceCache.append(token);
					} else {
						if (charSequenceCache.length() > 0) {
							String charSeq = charSequenceCache.toString();
							tokens.add(new Token(charSeq, Token.isCharSequence, 
									Token.isNotFollowedBySpace, 0, guessPOSIndex(charSeq)));
							charSequenceCache.setLength(0);
						}
						tokens.add(new Token(twoWords.getFirst(), Token.isWord, Token.isNotFollowedBySpace, twoWords.getSecond(), wordPosIndexArray[twoWords.getSecond()]));
						tempWordToken = new Token(twoWords.getThird(), Token.isWord, Token.isNotFollowedBySpace, twoWords.getFourth(), wordPosIndexArray[twoWords.getFourth()]);
						tokens.add(tempWordToken);
					}
				}
			}
			
			token = text.substring(i, i + 1);
			switch (token) {
			case " ":
				if (tempWordToken == null) {
					charSequenceCache.append(' ');
				} else {
					tempWordToken.setFollowedByASpace(true);
				}
				break;
			default:
				//may also be a word, but is never composed of two words
				int wordIndex = wordIndexMap.get(token);
				if (wordIndex > 0) { 
					if (charSequenceCache.length() > 0) {
						String charSeq = charSequenceCache.toString();
						tokens.add(new Token(charSeq, Token.isCharSequence, 
								Token.isNotFollowedBySpace, 0, guessPOSIndex(charSeq)));
						charSequenceCache.setLength(0);
					}
					tempWordToken = new Token(token, Token.isWord, Token.isNotFollowedBySpace, wordIndex, wordPosIndexArray[wordIndex]);
					tokens.add(tempWordToken);
				} else {
					charSequenceCache.append(token);
				}
				break;
			}
			start = i + 1;
		}
		
		
		if (start < charsLength) {
			token = text.substring(start);
			int wordIndex = wordIndexMap.get(text.substring(start));
			if (wordIndex > 0) { 
				if (charSequenceCache.length() > 0) {
					String charSeq = charSequenceCache.toString();
					tokens.add(new Token(charSeq, Token.isCharSequence, 
							Token.isNotFollowedBySpace, 0, guessPOSIndex(charSeq)));
				}
				tokens.add(new Token(token, Token.isWord, 
						Token.isNotFollowedBySpace, wordIndex, wordPosIndexArray[wordIndex]));
			} else {
				charSequenceCache.append(token);
				String charSeq = charSequenceCache.toString();
				tokens.add(new Token(charSeq, Token.isCharSequence, Token.isNotFollowedBySpace, 0, guessPOSIndex(charSeq)));
			}
		} else if (charSequenceCache.length() > 0){
			String charSeq = charSequenceCache.toString();
			tokens.add(new Token(charSeq, Token.isCharSequence, Token.isNotFollowedBySpace, 0, guessPOSIndex(charSeq)));
		}
		
		return tokens;
	}
	
	
	
	/**
	 * thenAWord : correspond to 'tokenType' field of CompressionToken
	 * isFollowedByASpace: correspond to 'isFollowedByASpace' field of CompressionToken
	 *  
	 * @param thisPreTokenType
	 * 1: space, then a word
	 * 01: space, then not a word
	 * 001: not space, then a word
	 * 000: not space, then not a word
	 */
	protected void addWordPaddingBits(Token token1, Token token2, BitSet bitSet) {
		boolean followsASpace = token1.isFollowedByASpace();
		boolean followsAWord = token2.getTokenType() == Token.isWord;		
	
		if (followsASpace) {
			if (followsAWord){
				bitSet.set(offset++);
			} else {
				bitSet.set(offset + 1);
				offset += 2;
			}
		} else {
			if (followsAWord){
				bitSet.set(offset + 2);
				offset += 3;
			} else {
				offset += 3;
			}
		}
	}
	
	
	private void addPosTransitionBits(Token token1, Token token2, BitSet bitSet) {
		byte posIndex1 = token1.getEndPosIndex();
		byte posIndex2 = token2.getStartPosIndex();
		boolean[] bits = getPosTransitionBits(posIndex1, posIndex2);
		offset = BitSetUtils.addBits(bitSet, offset, bits);
	}
	
	
	private void addWordTokenBits(Token token2, BitSet bitSet) {
		byte posIndex = token2.getEndPosIndex();
		HuffmanIntegerInfo info = posesWordsHuffmanInfos.get(posIndex);
		boolean[] wordBits = info.getEncodeBits(token2.getWordIndex());
		offset = BitSetUtils.addBits(bitSet, offset, wordBits);
	}
	
	private void addCharSequenceTokenBits(Token token, BitSet bitSet) {
		ArrayList<boolean[]> bitsList = tokenizeByCharsInReverseOrder(token.getToken());
		for (int i = bitsList.size() - 1; i >= 0; i--){
			offset = BitSetUtils.addBits(bitSet, offset, bitsList.get(i));
		}
	}
	
	private Token addCharSequence(StringBuilder charSequenceCache, Token previousToken, BitSet bitSet){
		String charSeq = charSequenceCache.toString();
		Token charSeqToken = new Token(charSeq, 
				Token.isCharSequence, Token.isNotFollowedBySpace, 0, guessPOSIndex(charSeq));
		addEncodingBits(previousToken, charSeqToken, bitSet);
		charSequenceCache.setLength(0);
		return charSeqToken;
	}
	
	public void addEncodingBits(Token token1, Token token2, BitSet bitSet) {
		if (token1.getTokenType() == Token.isWord){
			addWordPaddingBits(token1, token2, bitSet);
		}
		if (token2.getTokenType() == Token.isWord){
			addPosTransitionBits(token1, token2, bitSet);
			switch (token2.getStartPosIndex()) {
			case COMMA:
			case EX:
			case EX_C:
			case RBS:
			case TO_C:
			case WP$:
				return;
			default:
				break;
			}
			addWordTokenBits(token2, bitSet);
		} else {
			addCharSequenceTokenBits(token2, bitSet);
		}
	}
	
	
	
	/**
	 * @return next posIndex
	 */
	private byte decodeWord(BitSet bitSet, MutableInt offset, StringBuilder builder, int previousPosIndex){
		//decode transition pos
		HuffmanByteInfo nextPosInfo = posesHuffmanInfos.get(previousPosIndex);
		byte nextPosIndex = nextPosInfo.getDecodedElement(bitSet, offset);
		switch (nextPosIndex) {
		case COMMA:
			builder.append(',');
			return nextPosIndex;
		case EX:
			builder.append("there");
			return nextPosIndex;
		case EX_C:
			builder.append("There");
			return nextPosIndex;
		case RBS:
			builder.append("most");
			return nextPosIndex;
		case TO_C:
			builder.append("To");
			return nextPosIndex;
		case WP$:
			builder.append("whose");
			return nextPosIndex;
		default:
			break;
		}
		//decode pos word
		HuffmanIntegerInfo nextWordInfo = posesWordsHuffmanInfos.get(nextPosIndex);
		int wordIndex = nextWordInfo.getDecodedElement(bitSet, offset);
		builder.append(wordArray[wordIndex]);
		return nextPosIndex;
	}
	
	/**
	 * @return next posIndex
	 */
	private byte decodeCharSequence(BitSet bitSet, MutableInt offset, StringBuilder builder){
		StringBuilder tempBuilder = new StringBuilder();
		
		char lastChar = ' ';
		do {
			String chars = charsHuffmanInfo.getDecodedElement(bitSet, offset);
			switch (chars) {
			case "▼":	//1024, extra 10
				char ch = (char) BitSetUtils.readIntFromBits(bitSet, offset, 10);
				tempBuilder.append(ch);
				continue;
			case "▲":	//65536, extra 16
				ch = (char) BitSetUtils.readIntFromBits(bitSet, offset, 16);
				tempBuilder.append(ch);
				continue;
			default:
				break;
			}
			tempBuilder.append(chars);
			lastChar = chars.charAt(chars.length() - 1);
		} while (lastChar != '\0');
		String charSeq = tempBuilder.substring(0, tempBuilder.length() - 1);
		builder.append(charSeq);
		return (byte) (-guessPOSIndex(charSeq));
	}
	
	public byte decodeAfterCharSequence(BitSet bitSet, MutableInt offset, StringBuilder builder, byte previousPosIndex){
		return decodeWord(bitSet, offset, builder, -previousPosIndex);
	}
	
	/** @param thisPreTokenType
	 * 1: space, then a word
	 * 01: space, then not a word
	 * 001: not space, then a word
	 * 000: not space, then not a word
	 */
	public byte decodeAfterWord(BitSet bitSet, MutableInt offset, StringBuilder builder, byte previousPosIndex){
		int index = offset.getInteger();
		if (bitSet.get(index++)){
			builder.append(' ');
			offset.add(1);
			/**1: space, then a word*/
			return decodeWord(bitSet, offset, builder, previousPosIndex);
		}
		
		if (bitSet.get(index++)){
			/**01: space, then not a word*/
			builder.append(' ');
			offset.add(2);
			return decodeCharSequence(bitSet, offset, builder);
		}
		
		if (bitSet.get(index++)){
			/**001: not space, then a word*/
			offset.add(3);
			return decodeWord(bitSet, offset, builder, previousPosIndex);
		} else {
			/**000: not space, then not a word*/
			offset.add(3);
			return decodeCharSequence(bitSet, offset, builder);
		}
		
	}
	
	private EnTextCompressionInfo() {
		
	}

	public static void main(String[] args) {
//		create();
//		recreateCompressionInfo();
//		adjustWordInfoMap();
	}



	
	
}

