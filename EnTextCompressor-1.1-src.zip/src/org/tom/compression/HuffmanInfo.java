package org.tom.compression;

import gnu.trove.map.hash.TObjectIntHashMap;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Map.Entry;

import org.tom.common.BinaryTree;
import org.tom.common.BitSet;
import org.tom.common.Frequencies;
import org.tom.common.MutableInt;
import org.tom.common.Pair;
import org.tom.utils.BitSetUtils;

/**
 * afterwards the HashMap will be changed to one using trove library
 * 
 * @author Tom3_Lin
 *
 */
public class HuffmanInfo<T> implements Serializable {

	private static final long serialVersionUID = 1L;

	private BinaryTree<T> decodeTree;
	private TObjectIntHashMap<T> encodePositionMap;

	public HuffmanInfo(BinaryTree<T> decodeTree, TObjectIntHashMap<T> encodePositionMap) {
		this.decodeTree = decodeTree;
		this.encodePositionMap = encodePositionMap;
	}
	
	/**
	 * should make sure the element exits
	 */
	public boolean[] getEncodeBits(T element){
		int position = encodePositionMap.get(element);
		return BitSetUtils.toTraversalBits(position);
	}
	
	
	public T getDecodedElement(BitSet bitSet, MutableInt offset){
		BinaryTree<T> target = decodeTree.traverseQuick(bitSet, offset);
		return target.getObject();
	}
	
	
	public static <T extends Comparable<T>> HuffmanInfo<T> create(Frequencies<T> frequencies) {
		BinaryTree<Pair<T, Long>> treeWithValues = createHuffmanDecodeTreeWithValue(frequencies);
		BinaryTree<T> decodeTree = toTreeWithoutValues(treeWithValues);
		TObjectIntHashMap<T> encodePositionMap = createEncodePositionMap(decodeTree);
		return new HuffmanInfo<T>(decodeTree, encodePositionMap);
	}
	 
	
	public static <T> TObjectIntHashMap<T> createEncodePositionMap(BinaryTree<T> decodeTree){
		decodeTree.setIndex(1);
		TObjectIntHashMap<T> positionMap = new TObjectIntHashMap<T>();
		if (decodeTree.getObject() != null){
			positionMap.put(decodeTree.getObject(), 1);
		}
		
		ArrayList<BinaryTree<T>> tempNodes = new ArrayList<BinaryTree<T>>(30);
		tempNodes.add(decodeTree);
		while (tempNodes.size() > 0){
			ArrayList<BinaryTree<T>> newTempNodes = new ArrayList<BinaryTree<T>>();
			for (BinaryTree<T> node : tempNodes){
				Integer nodeIndex = node.getIndex();
				BinaryTree<T> itsLeft = node.getLeft();
				if (itsLeft != null){
					int index = nodeIndex << 1;
					itsLeft.setIndex(index);
					if (itsLeft.getObject() != null)
						positionMap.put(itsLeft.getObject(), index);
					newTempNodes.add(itsLeft);
				}
				BinaryTree<T> itsRight = node.getRight();
				if (itsRight != null){
					int index = (nodeIndex << 1) + 1;
					itsRight.setIndex(index);
					if (itsRight.getObject() != null)
						positionMap.put(itsRight.getObject(), index);
					newTempNodes.add(itsRight);
				}
			}
			tempNodes = newTempNodes;
		}
		return positionMap;
	}
	
	
	private static <K> BinaryTree<K> toTreeWithoutValues(BinaryTree<Pair<K, Long>> treeWithValues){
		if (treeWithValues == null)
			return null;
		BinaryTree<K> treeWithoutValues = new BinaryTree<K>();
		
		treeWithoutValues.setObject(treeWithValues.getObject() == null ? null : treeWithValues.getObject().getKey());
		if (treeWithValues.getLeft() != null){
			BinaryTree<K> left = toTreeWithoutValues(treeWithValues.getLeft());
			treeWithoutValues.setLeft(left);
		}
		if (treeWithValues.getRight() != null){
			BinaryTree<K> right = toTreeWithoutValues(treeWithValues.getRight());
			treeWithoutValues.setRight(right);
		}
		return treeWithoutValues;
	}
	
	private static <T extends Comparable<T>> BinaryTree<Pair<T, Long>> createHuffmanDecodeTreeWithValue(
			HashMap<T, Long> frequencies) {
		
		PriorityQueue<BinaryTree<Pair<T, Long>>> priorityQueue = new PriorityQueue<>(
			new Comparator<BinaryTree<Pair<T, Long>>>() {
				@Override
				public int compare(BinaryTree<Pair<T, Long>> o1, BinaryTree<Pair<T, Long>> o2) {
					return o1.getObject().getValue().compareTo(o2.getObject().getValue());
			}
		});

		Iterator<Entry<T, Long>> iterator = frequencies.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<T, Long> entry = iterator.next();
			Pair<T, Long> comparablePair = new Pair<T, Long>(entry.getKey(), entry.getValue());
			priorityQueue.add(new BinaryTree<Pair<T, Long>>(comparablePair));
		}
		while (priorityQueue.size() > 1) {
			BinaryTree<Pair<T, Long>> t1 = priorityQueue.poll();
			BinaryTree<Pair<T, Long>> t2 = priorityQueue.poll();
			BinaryTree<Pair<T, Long>> merged = new BinaryTree<Pair<T, Long>>(t1, t2);
			merged.setObject(new Pair<T, Long>(null, t1.getObject().getValue() + t2.getObject().getValue()));
			priorityQueue.add(merged);
		}
		return priorityQueue.peek();
	}

	
	
	/**
	 * @return the decodeTree
	 */
	public BinaryTree<T> getDecodeTree() {
		return decodeTree;
	}

	/**
	 * @param decodeTree
	 *            the decodeTree to set
	 */
	public void setDecodeTree(BinaryTree<T> decodeTree) {
		this.decodeTree = decodeTree;
	}

	/**
	 * @return the encodePositionMap
	 */
	public TObjectIntHashMap<T> getEncodePositionMap() {
		return encodePositionMap;
	}

	/**
	 * @param encodePositionMap
	 *            the encodePositionMap to set
	 */
	public void setEncodePositionMap(TObjectIntHashMap<T> encodePositionMap) {
		this.encodePositionMap = encodePositionMap;
	}

}
