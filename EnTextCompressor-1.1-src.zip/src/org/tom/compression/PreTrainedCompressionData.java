package org.tom.compression;

import java.io.Serializable;
import java.util.HashMap;

import org.tom.common.Frequencies;
import org.tom.common.WordInfo;
import org.tom.utils.ObjectSerializer;

public class PreTrainedCompressionData implements Serializable{

	private static final long serialVersionUID = 1L;

	public HashMap<String, WordInfo> wordInfoMap;
	public Frequencies<String> topCharsFrequencies;
	
	private static void manuallyAdjustSomeEntries(HashMap<String, WordInfo> wordInfoMap) {
		wordInfoMap.remove("9E9E9");
		wordInfoMap.remove("CiconiiformesFamily");
		wordInfoMap.remove("PelecaniformesFamily");
		wordInfoMap.remove("CoraciiformesFamily");
		wordInfoMap.remove("GruiformesFamily");
		wordInfoMap.remove("FalconiformesFamily");
		
		wordInfoMap.put("ly", new WordInfo("RB", 320000L));
		wordInfoMap.get("ing").setPos("VBG");
		
	}
	
	public static void main(String[] args) {
		HashMap<String, WordInfo> wordInfoMap = 
				ObjectSerializer.deserialize("D:/Temp/wordInfoMap_withCapitalization.ser.gz", true);
		Frequencies<String> topCharsFrequencies = 
				ObjectSerializer.deserialize( "D:/Temp/topCharsFrequencies.ser.gz", true);
		manuallyAdjustSomeEntries(wordInfoMap);
		
		PreTrainedCompressionData data = new PreTrainedCompressionData();
		data.wordInfoMap = wordInfoMap;
		data.topCharsFrequencies = topCharsFrequencies;
		ObjectSerializer.serialize(data, "D:/Temp/preTrainedCompressionData.ser.gz", true);
	}
}
