package org.tom.compression;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import org.tom.common.Frequencies;
import org.tom.common.WordInfo;
import org.tom.utils.ObjectSerializer;

public class PreTrainedCompressionData implements Serializable{

	private static final long serialVersionUID = 1L;

	public HashMap<String, WordInfo> wordInfoMap;
	public Frequencies<String> topCharsFrequencies;
	public Frequencies<String> posBigramFrequencies;
	 
	private static void manuallyAdjustSomeEntries(HashMap<String, WordInfo> wordInfoMap) {
		wordInfoMap.remove("9E9E9");
		wordInfoMap.remove("CiconiiformesFamily");
		wordInfoMap.remove("PelecaniformesFamily");
		wordInfoMap.remove("CoraciiformesFamily");
		wordInfoMap.remove("GruiformesFamily");
		wordInfoMap.remove("FalconiformesFamily");
		
		wordInfoMap.put("ly", new WordInfo("RB", 320000L));
		wordInfoMap.get("ing").setPos("VBG");
		wordInfoMap.get("\"").setFrequency(28000000);
		
		Iterator<Entry<String, WordInfo>> iterator1 = wordInfoMap.entrySet().iterator();
		while (iterator1.hasNext()){
			Entry<String, WordInfo> entry = iterator1.next();
			if (entry.getValue().isPhrase() == false)
				continue;
			if (entry.getKey().contains(" ") == false){
				iterator1.remove();
				continue;
			}
		}
	}

	protected static void serializePreTrainedCompressionData_old() {
		HashMap<String, WordInfo> wordInfoMap = 
				ObjectSerializer.deserialize("D:/Temp/wordInfoMap_withCapitalization.ser.gz", true);

		Frequencies<String> topCharsFrequencies = 
				ObjectSerializer.deserialize( "D:/Temp/topCharsFrequencies.ser.gz", true);
		Frequencies<String> posBigramFrequencies = 
				ObjectSerializer.deserialize("D:/Temp/posBigramFrequencies.ser.gz", true);
		manuallyAdjustSomeEntries(wordInfoMap);
		
		PreTrainedCompressionData data = new PreTrainedCompressionData();
		data.wordInfoMap = wordInfoMap;
		data.topCharsFrequencies = topCharsFrequencies;
		data.posBigramFrequencies = posBigramFrequencies;
		ObjectSerializer.serialize(data, "D:/Temp/preTrainedCompressionData.ser.gz", true);
	}
	
	protected static void serializePreTrainedCompressionData() {
		HashMap<String, WordInfo> wordInfoMap = 
				ObjectSerializer.deserialize("D:/Temp/wordInfoMap.ser.gz", true);
		Frequencies<String> topCharsFrequencies = 
				ObjectSerializer.deserialize( "D:/Temp/syllablesFrequencies.ser.gz", true);
		Frequencies<String> posBigramFrequencies = 
				ObjectSerializer.deserialize("D:/Temp/posBigramFrequencies.ser.gz", true);
		manuallyAdjustSomeEntries(wordInfoMap);
		
		PreTrainedCompressionData data = new PreTrainedCompressionData();
		data.wordInfoMap = wordInfoMap;
		data.topCharsFrequencies = topCharsFrequencies;
		data.posBigramFrequencies = posBigramFrequencies;
		ObjectSerializer.serialize(data, "D:/Temp/preTrainedCompressionData.ser.gz", true);
	}
	
	
	
	public static void main(String[] args) {
		
		serializePreTrainedCompressionData();
	}
}
