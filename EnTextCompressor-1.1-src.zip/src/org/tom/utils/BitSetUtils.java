package org.tom.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.tom.common.BitSet;
import org.tom.common.MutableInt;


/**
 * an utility class for BitSet
 * @author Tom3_Lin
 */
public class BitSetUtils {
	
	private static final boolean[][] traversalBits;
	
	static {
		traversalBits = new boolean[10001][];
		for (int i = 1; i <= 10000; i++) {
			traversalBits[i] = toTraversalBits2(i);
		}
	}
	
	public static ArrayList<Boolean> intToBooleans(int integer){
		ArrayList<Boolean> booleans = new ArrayList<Boolean>(16);
		while (integer > 0){
			booleans.add( (integer & 1) > 0 ? true : false);
			integer = integer >> 1;
		}
		return booleans;
	}
	
	public static ArrayList<Boolean> intToBooleans(int integer, int numBits){
		ArrayList<Boolean> booleans = new ArrayList<Boolean>(numBits);
		for (int i = 0; i < numBits; i++){
			booleans.add( (integer & 1) > 0 ? true : false);
			integer = integer >> 1;
		}
		return booleans;
	}
	
	/**
	 * not recommended to use
	 * @param integer
	 */
	public static ArrayList<Boolean> toTraversalBitsList(int integer){
		ArrayList<Boolean> booleans = BitSetUtils.intToBooleans(integer);
		if (booleans.size() > 0){
			booleans.remove(booleans.size() - 1);
		}
		Collections.reverse(booleans);
		return booleans;
	}
	
	public static boolean[] toTraversalBits(int position){
		if (position <= 10000){
			return traversalBits[position];
		}
		
		boolean[] bs = new boolean[31];
		int index = 30;
		while (position > 0) {
			bs[index--] = (position & 1) == 1;
			position >>= 1;
		}
		int newLength = 29 - index;
		boolean[] copy = new boolean[newLength];
	    System.arraycopy(bs, index + 2, copy, 0, newLength);
		return copy;
	}
	
	
	
	public static boolean[] toTraversalBits2(int position){
		int numberOfLeadingZeros = Integer.numberOfLeadingZeros(position);
		int lengthMinus1 = 30 - numberOfLeadingZeros;
		boolean[] bs = new boolean[lengthMinus1 + 1];
		for (int i = lengthMinus1; i >= 0; i--){
			bs[lengthMinus1 - i] = (position & (1 << i)) > 0;
		}
		return bs;
	}
	
	public static boolean[] toTraversalBits3(int position){
		
		int bit = 1;
		int numBitsPlus1 = 0;
		while (bit <= position){
			bit <<= 1;
			numBitsPlus1++;
		}
		bit >>= 2;
		boolean[] bits = new boolean[numBitsPlus1 - 1];
		int index = 0;
		while (bit > 0){
			bits[index++] = (position & bit) > 0;
			bit >>= 1;
		}
		return bits;
	}
	
	
	
	public static char booleansToChar(boolean[] booleans){
		return booleansToChar(booleans, 0);
	}
	
	public static char booleansToChar(boolean[] booleans, int offset){
		char c = 0;
		int b = 1;
		for (int i = 0; i < 16; i++){
			if (booleans[offset + i]){
				c += b;
			}
			b = b << 1;
		}
		return c;
	}
	public static char booleansToChar(BitSet bitSet, int offset){
		char c = 0;
		int b = 1;
		for (int i = 0; i < 16; i++){
			if (bitSet.get(offset + i)){
				c += b;
			}
			b = b << 1;
		}
		return c;
	}
	public static char booleansToRareChar(BitSet bitSet, int offset){
		char c = 0;
		int b = 1;
		for (int i = 0; i < 24; i++){
			if (bitSet.get(offset + i)){
				c += b;
			}
			b = b << 1;
		}
		return c;
	}
	
	public static boolean[] charToBooleans(char c){
		int b = 1;
		boolean[] booleans = new boolean[16];
		for (int i = 0; i < 16; i++){
			if ((c & b) > 0){
				booleans[i] = true;
			}
			b = b << 1;
		}
		return booleans;
	}
	
	public static int addBits(BitSet bitSet, int offset, boolean[] bits){
		for (int i = 0; i < bits.length; i++ ){
			bitSet.set(offset++, bits[i]);
		}
		return offset;
	}
	
	public static int addBits(BitSet bitSet,  int offset, List<boolean[]> bitsList) {
	
		for (boolean[] bits : bitsList) {
			for (int i = 0; i < bits.length; i++){
				bitSet.set(offset++, bits[i]);
			}
		}
		return offset;
	}



	/**
	 * @param codePoint
	 */
	public static boolean[] toBits(int codePoint, final int numBits) {
		boolean[] bits = new boolean[numBits];
		for(int i = 0; i < numBits; i++){
			bits[i] = (codePoint & 1) > 0;
			codePoint >>= 1;
		}
		return bits;
	}
	
	public static int readIntFromBits(BitSet bitSet, MutableInt offset, final int numBits){
		final int startIndex = offset.getInteger();
		int integer = 0;
		for (int i = startIndex + numBits - 1; i >= startIndex; i--){
			integer <<= 1;
			if (bitSet.get(i)) {
				integer++;
			}
		}
		offset.setInteger(startIndex + numBits);
		return integer;
	}
	
	public static int fromBits(boolean[] bits) {
		int integer = 0;
		for (int i = bits.length - 1; i >= 0; i--){
			integer <<= 1;
			if (bits[i]) {
				integer++;
			}
		}
		return integer;
	}
	
	public static void addBitSet(BitSet bitSet, BitSet anotherBitSet, int offset, int length){
    	int end = offset + length;
    	int anotherIndex = 0;
    	for (int i = offset; i < end; i++){
    		bitSet.set(i, anotherBitSet.get(anotherIndex++));
    	}
    }

	
}
