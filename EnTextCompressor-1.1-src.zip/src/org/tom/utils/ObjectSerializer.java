package org.tom.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * 
 * @author Tom3_Lin
 *
 */
public class ObjectSerializer {

	public static <T extends Serializable> boolean serialize(T object, String filePath) {
		return serialize(object, filePath, false);
	}
	
	private static boolean createDirectoryByPath(String path) {
		int slashIndex = path.lastIndexOf('/');
		if (slashIndex == -1)
			return false;
		String directory = path.substring(0, slashIndex);
		return createDirectory(directory, true);
	}

	private static boolean createDirectory(String directory, boolean recursively) {	
		File dir = new File(directory);
		if (dir.exists() == false) {
			boolean success = recursively ? dir.mkdirs() : dir.mkdir();
			if (success) {
				System.err.println("FileUtils.createDirectory(): created directory " + directory);
			}
			return success;
		}
		return true;
	}
	
	
	public static <T extends Serializable> boolean serialize(T object, String filePath, boolean useGZip) {
		try {
			createDirectoryByPath(filePath);
			
			FileOutputStream fout = new FileOutputStream(filePath);
			ObjectOutputStream oout = new ObjectOutputStream(useGZip ? new GZIPOutputStream(fout) : fout);
			oout.writeObject(object);
			oout.close();
			fout.close();
			System.err.println("Serialized the " + object.getClass().getSimpleName() + " to " + filePath);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}	
	}

	
	public static <T extends Serializable> T deserialize(String filePath) {
		return deserialize(filePath, false);
	}

	@SuppressWarnings("unchecked")
	public static <T extends Serializable> T deserialize(String filePath, boolean useGZip) {
		try {
			FileInputStream fis = new FileInputStream(filePath);
			ObjectInputStream ois = new ObjectInputStream(useGZip ? new GZIPInputStream(fis) : fis);
			T object = (T) ois.readObject();
			ois.close();
			fis.close();
			return object;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} 
	}

}
