package org.tom.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.GZIPInputStream;

/**
 * @author Tom3_Lin
 *
 */
public class FileUtils {
	@SuppressWarnings("unchecked")
	public static <T extends Serializable> T fromInputStream(InputStream inputStream) {
		try {
			ObjectInputStream ois = new ObjectInputStream(new GZIPInputStream(inputStream) );
			Object object = ois.readObject();
			ois.close();
			return (T) object;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static void write(String text, String filePath) {
		try {
			OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(filePath));
			writer.write(text);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void writeInputStream(InputStream inputStream, String outputPath) {
		final Path destination = Paths.get(outputPath);
	    try {
			Files.copy(inputStream, destination);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static byte[] readBytes(String filePath) {
		try {
			return Files.readAllBytes(new File(filePath).toPath());
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static String read(String path) {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path), StandardCharsets.UTF_8));
			StringBuilder builder = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				builder.append(line + "\n");
			}
			reader.close();
			return builder.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
