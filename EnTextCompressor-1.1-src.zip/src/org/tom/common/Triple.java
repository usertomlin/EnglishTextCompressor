package org.tom.common;

import java.io.Serializable;

/**
 * @author Tom3_Lin
 *
 */
public class Triple<T1, T2, T3> implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public T1 first;
	public T2 second;
	public T3 third;

	public Triple(T1 first, T2 second, T3 third) {
		this.first = first;
		this.second = second;
		this.third = third;
	}

	
	/**
	 * @return the first
	 */
	public T1 getFirst() {
		return first;
	}

	/**
	 * @param first the first to set
	 */
	public void setFirst(T1 first) {
		this.first = first;
	}

	/**
	 * @return the second
	 */
	public T2 getSecond() {
		return second;
	}

	/**
	 * @param second the second to set
	 */
	public void setSecond(T2 second) {
		this.second = second;
	}

	/**
	 * @return the third
	 */
	public T3 getThird() {
		return third;
	}

	/**
	 * @param third the third to set
	 */
	public void setThird(T3 third) {
		this.third = third;
	}


	@Override
	public int hashCode() {
		int result;
		result = (first != null ? first.hashCode() : 0);
		result = 29 * result + (second != null ? second.hashCode() : 0);
		result = 29 * result + (third != null ? third.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return "(" + first + "," + second + "," + third + ")";
	}


	/**
	 * Returns a Triple constructed from X, Y, and Z. Convenience method; the
	 * compiler will disambiguate the classes used for you so that you don't
	 * have to write out potentially long class names.
	 */
	public static <X, Y, Z> Triple<X, Y, Z> create(X x, Y y, Z z) {
		return new Triple<>(x, y, z);
	}


}
