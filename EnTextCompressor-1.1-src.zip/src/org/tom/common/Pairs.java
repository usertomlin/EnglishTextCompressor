package org.tom.common;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * @author Tom3_Lin
 *
 */
public class Pairs<K extends Comparable<K>, V extends Comparable<V>> extends ArrayList<Pair<K, V>>{

	private static final long serialVersionUID = 1L;

	public Pairs(){
		super();
	}
	public Pairs(int initialCapacity){
		super(initialCapacity);
	}
	
	public Pairs(List<Pair<K, V>> pairs){
		super(pairs);
	}
	
	public Pairs(Map<K, V> map){
		Iterator<Entry<K, V>> iterator = map.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<K, V> entry = iterator.next();
			add(new Pair<K, V>(entry.getKey(), entry.getValue()));
		}
	}
	
	/// /////////////////////////////////////////////////////////////
	
	public static <K extends Comparable<K>, V extends Comparable<V>> Pairs<K, V> toNoValuePairs(ArrayList<K> keys){
		Pairs<K, V> pairs = new Pairs<K, V>();
		for (K key : keys) {
			pairs.add(new Pair<K, V>(key, null));
		}
		return pairs;
	}
	public static <K extends Comparable<K>, V extends Comparable<V>> Pairs<K, V> toDefaultValuePairs(ArrayList<K> keys, V defaultValue){
		Pairs<K, V> pairs = new Pairs<K, V>();
		for (K key : keys) {
			pairs.add(new Pair<K, V>(key, defaultValue));
		}
		return pairs;
	}
	
	public static <K extends Comparable<K>, V extends Comparable<V>> Pairs<K, V> toNoKeyPairs(ArrayList<V> values){
		Pairs<K, V> pairs = new Pairs<K, V>();
		for (V value : values) {
			pairs.add(new Pair<K, V>(null, value));
		}
		return pairs;
	}
	
	public static <K extends Comparable<K>, V extends Comparable<V>> Pairs<K, V> toDefaultKeyPairs(ArrayList<V> values, K defaultKey){
		Pairs<K, V> pairs = new Pairs<K, V>();
		for (V value : values) {
			pairs.add(new Pair<K, V>(defaultKey, value));
		}
		return pairs;
	}
	
	//////////////////////////
	
	public Pairs<K, V> sortByKey(){
		Collections.sort(this, keyComparator());
		return this;
	}
	
	public Pairs<K, V> sortByValue(){
		Collections.sort(this, valueComparator());
		return this;
	}
	
	public ArrayList<K> getKeys(){
		ArrayList<K> keys = new ArrayList<K>();
		for (Pair<K, V> pair : this){
			keys.add(pair.getKey());
		}
		return keys;
	}
	
	public ArrayList<V> getValues(){
		ArrayList<V> keys = new ArrayList<V>();
		for (Pair<K, V> pair : this){
			keys.add(pair.getValue());
		}
		return keys;
	}
	
	public void add(K key, V value){
		super.add(new Pair<K, V>(key, value));
	}
	
	
	public Pairs<K, V> copy(){
		Pairs<K, V> pairs = new Pairs<K, V>();
		for (Pair<K, V> pair : this){
			pairs.add(new Pair<K, V>(pair.getKey(), pair.getValue()));
		}
		return pairs;
	}
	
	public ArrayList<K> keys(){
		ArrayList<K> keys = new ArrayList<K>();
		for (Pair<K, V> pair : this){
			keys.add(pair.getKey());
		}
		return keys;
	}
	
	public ArrayList<V> values(){
		ArrayList<V> values = new ArrayList<V>();
		for (Pair<K, V> pair : this){
			values.add(pair.getValue());
		}
		return values;
	}
	
	public Pairs<K, V> subList(int startIndex, int endIndex){
		List<Pair<K, V>> temp = super.subList(startIndex, endIndex);		
		return new Pairs<K, V>(temp);
	}

	public Pair<K, V> maxValuePair(){
		if (size() == 0)
			return null;
		else if (size() == 1){
			return get(0);
		}
		Pair<K, V> maxValuePair = get(0);
		for (int i = 1; i < size(); i++){
			Pair<K, V> pair = get(i);
			if (pair.getValue().compareTo(maxValuePair.getValue()) > 0){
				maxValuePair = pair;
			}
		}
		return maxValuePair;
	}
	
	public Pair<K, V> maxKeyPair(){
		if (size() == 0)
			return null;
		else if (size() == 1){
			return get(0);
		}
		Pair<K, V> maxKeyPair = get(0);
		for (int i = 1; i < size(); i++){
			Pair<K, V> pair = get(i);
			if (pair.getKey().compareTo(maxKeyPair.getKey()) > 0){
				maxKeyPair = pair;
			}
		}
		return maxKeyPair;
	}
	
	@Override
	public String toString(){
		StringBuilder builder = new StringBuilder(size() << 4);
		for (Pair<K, V> pair : this) {
			builder.append(pair.getKey() + ", " + pair.getValue());
		}
		return builder.toString();
	}
	
	
	/**for sorting frequency in descending order
	 */
	private final Comparator<Pair<K, V>> valueComparator(){ 
		return new Comparator<Pair<K, V>>() {
			@Override
			public int compare(Pair<K, V> o1, Pair<K, V> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}
		};
	};

	/**for sorting keys in natural order
	 */
	private final Comparator<Pair<K, V>> keyComparator(){ 
		return new Comparator<Pair<K, V>>() {
			@Override
			public int compare(Pair<K, V> o1, Pair<K, V> o2) {
				return o1.getKey().compareTo(o2.getKey());
			}
		};
	};
	
	/// /////////////////////////////////////////////////////////////
	/**
	 * create index to value pairs
	 * @param vec
	 * @return
	 */
	public static Pairs<Integer, Double> create(double[] vec){
		Pairs<Integer, Double> pairs = new Pairs<Integer, Double>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}
	public static Pairs<Integer, Double> create(Double[] vec){
		Pairs<Integer, Double> pairs = new Pairs<Integer, Double>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}
	

	public static Pairs<Integer, Float> create(float[] vec){
		Pairs<Integer, Float> pairs = new Pairs<Integer, Float>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}
	public static Pairs<Integer, Float> create(Float[] vec){
		Pairs<Integer, Float> pairs = new Pairs<Integer, Float>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}

	public static Pairs<Integer, Integer> create(int[] vec){
		Pairs<Integer, Integer> pairs = new Pairs<Integer, Integer>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}
	public static Pairs<Integer, Integer> create(Integer[] vec){
		Pairs<Integer, Integer> pairs = new Pairs<Integer, Integer>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}
	
}
