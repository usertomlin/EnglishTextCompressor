package org.tom.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;



/**
 * 
 * @author Tom3_Lin
 *
 */
public class BinaryTree<T> implements Serializable {

	private static final long serialVersionUID = 1L;
	protected T object;
	protected BinaryTree<T> left, right;
	
	protected Integer index;
	
	public BinaryTree(){
		
	}
	public BinaryTree(T object){
		this.object = object;
	}
	
	public BinaryTree(BinaryTree<T> left, BinaryTree<T> right){
		this.left = left;
		this.right = right;
	}

	/**
	 * shallow copy
	 */
	public BinaryTree<T> copy(){
		BinaryTree<T> newTree = new BinaryTree<T>(object);
		if (left != null)
			newTree.setLeft(left.copy());
		if (right != null)
			newTree.setRight(right.copy());
		return newTree;
	}
	
	public BinaryTree<T> traverseByPosition(int position){
		int numberOfLeadingZeros = Integer.numberOfLeadingZeros(position);
		int lengthMinus1 = 30 - numberOfLeadingZeros;
		BinaryTree<T> node = this;
		for (int i = lengthMinus1; i >= 0; i--){
			node = (position & (1 << i)) > 0 ? node.right: node.left;
		}
		return node;
	}
	
	/**
	 * does not check null
	 * @param bitSet
	 * @param offset
	 * @param object
	 */
	public BinaryTree<T> traverseQuick(BitSet bitSet, MutableInt offset){
		BinaryTree<T> node = this;
		int index = offset.getInteger();
		while (true) {
			node = bitSet.get(index++) ? node.right : node.left;
			if (node.object != null){
				offset.setInteger(index);
				return node;
			}
		}
	}
	
	public static void main(String[] args) {
		BinaryTree<Integer> tree = new BinaryTree<>(11);
		tree.setLeft(new BinaryTree<>(12));
		tree.setRight(new BinaryTree<>(13));
		tree.getLeft().setLeft(new BinaryTree<>(14));
		tree.getLeft().setRight(new BinaryTree<>(15));
		tree.getRight().setLeft(new BinaryTree<>(16));
		tree.getRight().setRight(new BinaryTree<>(17));
//		System.out.println("tree.getLeft() = " + tree.getLeft());
//		System.out.println(tree.traverse(1));
//		System.out.println(tree.traverse(2));
//		System.out.println(tree.traverse(8));
		
		System.out.println(tree.getEncodePositionMap());
		
	}
	
	/**
	 * get a position map for non-null objects at corresponding nodes  
	 *  
	 *     1
	 *   /   \ 
	 *  2     3
	 * / \   / \
	 *4   5 6   7
	 * should call this only on the root node
	 */
	public HashMap<T, Integer> getEncodePositionMap(){
		setIndex(1);
		HashMap<T, Integer> positionMap = new HashMap<>();
		if (object != null){
			positionMap.put(object, 1);
		}
		
		ArrayList<BinaryTree<T>> tempNodes = new ArrayList<BinaryTree<T>>(30);
		tempNodes.add(this);
		while (tempNodes.size() > 0){
			ArrayList<BinaryTree<T>> newTempNodes = new ArrayList<BinaryTree<T>>();
			for (BinaryTree<T> node : tempNodes){
				Integer nodeIndex = node.getIndex();
				BinaryTree<T> itsLeft = node.getLeft();
				if (itsLeft != null){
					int index = nodeIndex << 1;
					itsLeft.setIndex(index);
					if (itsLeft.getObject() != null)
						positionMap.put(itsLeft.getObject(), index);
					newTempNodes.add(itsLeft);
				}
				BinaryTree<T> itsRight = node.getRight();
				if (itsRight != null){
					int index = (nodeIndex << 1) + 1;
					itsRight.setIndex(index);
					if (itsRight.getObject() != null)
						positionMap.put(itsRight.getObject(), index);
					newTempNodes.add(itsRight);
				}
			}
			tempNodes = newTempNodes;
		}
		return positionMap;
	}
	
	
	private static <T> void setAtList(ArrayList<T> list, int i, T object){
		if (i < 0)
			return;
		else if (i < list.size()){
			list.set(i, object);
		} else {
			for (int j = list.size() ; j < i; j++){
				list.add(null);
			}
			list.add(object);
		}
	}
	
	/**should call this only on the root node
	 * @return
	 */
	public ArrayList<T> toArrayList(){
		index = 1;
		
		ArrayList<BinaryTree<T>> tempNodes = new ArrayList<BinaryTree<T>>(30);
		tempNodes.add(this);
		
		ArrayList<T> arrayNodes = new ArrayList<T>(30);
		setAtList(arrayNodes, index, object);

		while (tempNodes.size() > 0){
			ArrayList<BinaryTree<T>> newTempNodes = new ArrayList<BinaryTree<T>>();
			for (BinaryTree<T> node : tempNodes){
				Integer nodeIndex = node.getIndex();
				BinaryTree<T> itsLeft = node.getLeft();
				if (itsLeft != null){
					int index = nodeIndex << 1;
					itsLeft.setIndex(index);
					setAtList(arrayNodes, index, itsLeft.getObject());
					newTempNodes.add(itsLeft);
				}
				BinaryTree<T> itsRight = node.getRight();
				if (itsRight != null){
					int index = (nodeIndex << 1) + 1;
					itsRight.setIndex(index);
					setAtList(arrayNodes, index, itsRight.getObject());
					newTempNodes.add(itsRight);
				}
			}
			tempNodes = newTempNodes;
		}
		return arrayNodes;
	}
	
	
	/**
	 * @return the object
	 */
	public T getObject() {
		return object;
	}


	/**
	 * @param object the object to set
	 */
	public void setObject(T object) {
		this.object = object;
	}


	/**
	 * @return the left
	 */
	public BinaryTree<T> getLeft() {
		return left;
	}


	/**
	 * @param left the left to set
	 */
	public void setLeft(BinaryTree<T> left) {
		this.left = left;
	}


	/**
	 * @return the right
	 */
	public BinaryTree<T> getRight() {
		return right;
	}

	/**
	 * @param right the right to set
	 */
	public void setRight(BinaryTree<T> right) {
		this.right = right;
	}
	
	/**
	 * @return the index
	 */
	public Integer getIndex() {
		return index;
	}

	/**
	 * @param index the index to set
	 */
	public void setIndex(Integer index) {
		this.index = index;
	}

	@Override
	public String toString(){
		return object == null ? "null" : object.toString();
	}
}
