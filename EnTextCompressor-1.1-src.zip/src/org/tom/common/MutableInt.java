package org.tom.common;

public class MutableInt {

	
	private int integer;
	
	public MutableInt(){
		this.integer = 0;
	}
	public MutableInt(int integer){
		this.integer = integer;
	}
	
	public void increment(){
		integer ++;
	}
	
	public int plus(int i){
		integer += i;
		return integer;
	}
	
	public void decrement(){
		integer --; 
	}
	
	public int minus(int i){
		integer -= i;
		return integer;
	}
	
	public void add(int i){
		integer += i;
	}

	public void subtract(int i){
		integer -= i;
	}
	
	public int times(int i){
		integer *= i;
		return integer;
	}
	public int divides(int i){
		integer /= i;
		return integer;
	}
	
	/**
	 * @return the integer
	 */
	public int getInteger() {
		return integer;
	}
	/**
	 * @param integer the integer to set
	 */
	public void setInteger(int integer) {
		this.integer = integer;
	}
	
	public boolean isSmallerThan(int another){
		return integer < another;
	}
	
	@Override
	public String toString() {
		return integer + "";
	}

	
}
