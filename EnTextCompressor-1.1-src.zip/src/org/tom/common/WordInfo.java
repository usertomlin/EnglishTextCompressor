package org.tom.common;

import java.io.Serializable;

/**
 * an intermediate class; not used or stored in memory during runtime
 * @author Tom3_Lin
 *
 */
public class WordInfo implements Serializable, Comparable<WordInfo> {

	private static final long serialVersionUID = 1L;

	private String pos;
	private String endPos;
	private long frequency;
	private boolean isPhrase;
	
	//non-null if isPhrase is true
	private String word1, word2;
	
	
	/**
	 * @return the word1
	 */
	public String getWord1() {
		return word1;
	}

	/**
	 * @param word1 the word1 to set
	 */
	public void setWord1(String word1) {
		this.word1 = word1;
	}

	/**
	 * @return the word2
	 */
	public String getWord2() {
		return word2;
	}

	/**
	 * @param word2 the word2 to set
	 */
	public void setWord2(String word2) {
		this.word2 = word2;
	}

	/**@return the pos
	 */
	public String getPos() {
		return pos;
	}

	/**
	 * @param pos the pos to set
	 */
	public void setPos(String pos) {
		this.pos = pos;
	}

	/**
	 * @return the frequency
	 */
	public long getFrequency() {
		return frequency;
	}

	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(long frequency) {
		this.frequency = frequency;
	}

	/**
	 * @return the isPhrase
	 */
	public boolean isPhrase() {
		return isPhrase;
	}

	/**
	 * @param isPhrase the isPhrase to set
	 */
	public void setPhrase(boolean isPhrase) {
		this.isPhrase = isPhrase;
	}

	
	public WordInfo(String pos, long frequency) {
		this.pos = pos;
		this.frequency = frequency;
	}

	@Override
	public int compareTo(WordInfo o) {
		if (isPhrase == false && o.isPhrase == true)
			return -1;
		if (isPhrase == true && o.isPhrase == false)
			return 1;
		return (int) (frequency - o.frequency);
	}
	
	public String toString(){
		return pos + "-" + frequency;
	}

	/**
	 * @return the endPos
	 */
	public String getEndPos() {
		return endPos;
	}

	/**
	 * @param endPos the endPos to set
	 */
	public void setEndPos(String endPos) {
		this.endPos = endPos;
	}

	
}
