package org.tom.common;

import java.io.Serializable;

/**
 * A quadruple of objects.
 * 
 * @param <T1>
 * @param <T2>
 * @param <T3>
 * @param <T4>
 */
public class Quadruple<T1, T2, T3, T4> implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public T1 first;
	public T2 second;
	public T3 third;
	public T4 fourth;

	public Quadruple(T1 first, T2 second, T3 third, T4 fourth) {
		this.first = first;
		this.second = second;
		this.third = third;
		this.fourth = fourth;
	}


	/**
	 * @return the first
	 */
	public T1 getFirst() {
		return first;
	}

	/**
	 * @param first the first to set
	 */
	public void setFirst(T1 first) {
		this.first = first;
	}

	/**
	 * @return the second
	 */
	public T2 getSecond() {
		return second;
	}

	/**
	 * @param second the second to set
	 */
	public void setSecond(T2 second) {
		this.second = second;
	}

	/**
	 * @return the third
	 */
	public T3 getThird() {
		return third;
	}

	/**
	 * @param third the third to set
	 */
	public void setThird(T3 third) {
		this.third = third;
	}

	/**
	 * @return the fourth
	 */
	public T4 getFourth() {
		return fourth;
	}

	/**
	 * @param fourth the fourth to set
	 */
	public void setFourth(T4 fourth) {
		this.fourth = fourth;
	}



	@Override
	public int hashCode() {
		int result = 17;
		result = (first != null ? first.hashCode() : 0);
		result = 29 * result + (second != null ? second.hashCode() : 0);
		result = 29 * result + (third != null ? third.hashCode() : 0);
		result = 29 * result + (fourth != null ? fourth.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return "(" + first + "," + second + "," + third + "," + fourth + ")";
	}

	/**
	 * Returns a Quadruple constructed from T1, T2, T3, and T4. Convenience
	 * method; the compiler will disambiguate the classes used for you so that
	 * you don't have to write out potentially long class names.
	 */
	public static <T1, T2, T3, T4> Quadruple<T1, T2, T3, T4> create(
			T1 t1, T2 t2, T3 t3, T4 t4) {
		return new Quadruple<>(t1, t2, t3, t4);
	}



}