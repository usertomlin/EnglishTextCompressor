package org.tom.common;


import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * @author Tom3_Lin
 *
 */
public class ComparablePairs<K extends Comparable<K>, V extends Comparable<V>> extends ArrayList<ComparablePair<K, V>>{

	private static final long serialVersionUID = 1L;

	public ComparablePairs(){
		super();
	}
	public ComparablePairs(int initialCapacity){
		super(initialCapacity);
	}
	
	public ComparablePairs(List<ComparablePair<K, V>> pairs){
		super(pairs);
	}
	
	public ComparablePairs(Map<K, V> map){
		Iterator<Entry<K, V>> iterator = map.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<K, V> entry = iterator.next();
			add(new ComparablePair<K, V>(entry.getKey(), entry.getValue()));
		}
	}
	
	public static <K extends Comparable<K>, V extends Comparable<V>> ComparablePairs<K, V> create(Map<K, V> map){
		return new ComparablePairs<K, V>(map);
	}
	
	//////////////////////////
	
	public ComparablePairs<K, V> sortByAscendingKeys(){
		Collections.sort(this, ascendingKeyComparator());
		return this;
	}
	
	public ComparablePairs<K, V> sortByDescendingKeys(){
		Collections.sort(this, descendingKeyComparator());
		return this;
	}
	public ComparablePairs<K, V> sortByAscendingValues(){
		Collections.sort(this, ascendingValueComparator());
		return this;
	}
	public ComparablePairs<K, V> sortByDescendingValues(){
		Collections.sort(this, descendingValueComparator());
		return this;
	}
	
	public ArrayList<K> getKeys(){
		ArrayList<K> keys = new ArrayList<K>();
		for (ComparablePair<K, V> pair : this){
			keys.add(pair.getKey());
		}
		return keys;
	}
	
	public ArrayList<V> getValues(){
		ArrayList<V> keys = new ArrayList<V>();
		for (ComparablePair<K, V> pair : this){
			keys.add(pair.getValue());
		}
		return keys;
	}
	
	public void add(K key, V value){
		super.add(new ComparablePair<K, V>(key, value));
	}
	
	
	public ComparablePairs<K, V> copy(){
		ComparablePairs<K, V> pairs = new ComparablePairs<K, V>();
		for (ComparablePair<K, V> pair : this){
			pairs.add(new ComparablePair<K, V>(pair.getKey(), pair.getValue()));
		}
		return pairs;
	}
	
	public ArrayList<K> keys(){
		ArrayList<K> keys = new ArrayList<K>();
		for (ComparablePair<K, V> pair : this){
			keys.add(pair.getKey());
		}
		return keys;
	}
	
	public ArrayList<V> values(){
		ArrayList<V> values = new ArrayList<V>();
		for (ComparablePair<K, V> pair : this){
			values.add(pair.getValue());
		}
		return values;
	}
	
	public ComparablePairs<K, V> subList(int startIndex, int endIndex){
		List<ComparablePair<K, V>> temp = super.subList(startIndex, endIndex);		
		return new ComparablePairs<K, V>(temp);
	}

	
	public ComparablePair<K, V> maxValuePair(){
		if (size() == 0)
			return null;
		else if (size() == 1){
			return get(0);
		}
		ComparablePair<K, V> maxValuePair = get(0);
		for (int i = 1; i < size(); i++){
			ComparablePair<K, V> pair = get(i);
			if (pair.getValue().compareTo(maxValuePair.getValue()) > 0){
				maxValuePair = pair;
			}
		}
		return maxValuePair;
	}
	
	public ComparablePair<K, V> maxKeyPair(){
		if (size() == 0)
			return null;
		else if (size() == 1){
			return get(0);
		}
		ComparablePair<K, V> maxKeyPair = get(0);
		for (int i = 1; i < size(); i++){
			ComparablePair<K, V> pair = get(i);
			if (pair.getKey().compareTo(maxKeyPair.getKey()) > 0){
				maxKeyPair = pair;
			}
		}
		return maxKeyPair;
	}
	
	public ComparablePair<K, V> minValuePair(){
		if (size() == 0)
			return null;
		else if (size() == 1){
			return get(0);
		}
		ComparablePair<K, V> minValuePair = get(0);
		for (int i = 1; i < size(); i++){
			ComparablePair<K, V> pair = get(i);
			if (pair.getValue().compareTo(minValuePair.getValue()) < 0){
				minValuePair = pair;
			}
		}
		return minValuePair;
	}
	
	public ComparablePair<K, V> minKeyPair(){
		if (size() == 0)
			return null;
		else if (size() == 1){
			return get(0);
		}
		ComparablePair<K, V> minKeyPair = get(0);
		for (int i = 1; i < size(); i++){
			ComparablePair<K, V> pair = get(i);
			if (pair.getKey().compareTo(minKeyPair.getKey()) < 0){
				minKeyPair = pair;
			}
		}
		return minKeyPair;
	}
	
	private final Comparator<ComparablePair<K, V>> ascendingValueComparator(){ 
		return new Comparator<ComparablePair<K, V>>() {
			@Override
			public int compare(ComparablePair<K, V> o1, ComparablePair<K, V> o2) {
				return o1.getValue().compareTo(o2.getValue());
			}
		};
	};
	
	/**for sorting frequency in descending order
	 */
	private final Comparator<ComparablePair<K, V>> descendingValueComparator(){ 
		return new Comparator<ComparablePair<K, V>>() {
			@Override
			public int compare(ComparablePair<K, V> o1, ComparablePair<K, V> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}
		};
	};

	/**for sorting keys in natural order
	 */
	private final Comparator<ComparablePair<K, V>> ascendingKeyComparator(){ 
		return new Comparator<ComparablePair<K, V>>() {
			@Override
			public int compare(ComparablePair<K, V> o1, ComparablePair<K, V> o2) {
				return o1.getKey().compareTo(o2.getKey());
			}
		};
	};
	
	private final Comparator<ComparablePair<K, V>> descendingKeyComparator(){ 
		return new Comparator<ComparablePair<K, V>>() {
			@Override
			public int compare(ComparablePair<K, V> o1, ComparablePair<K, V> o2) {
				return o2.getKey().compareTo(o1.getKey());
			}
		};
	};
	
	/// /////////////////////////////////////////////////////////////
	/**
	 * create index to value pairs
	 * @param vec
	 * @return
	 */
	public static ComparablePairs<Integer, Double> create(double[] vec){
		ComparablePairs<Integer, Double> pairs = new ComparablePairs<Integer, Double>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}
	public static ComparablePairs<Integer, Double> create(Double[] vec){
		ComparablePairs<Integer, Double> pairs = new ComparablePairs<Integer, Double>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}
	

	public static ComparablePairs<Integer, Float> create(float[] vec){
		ComparablePairs<Integer, Float> pairs = new ComparablePairs<Integer, Float>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}
	public static ComparablePairs<Integer, Float> create(Float[] vec){
		ComparablePairs<Integer, Float> pairs = new ComparablePairs<Integer, Float>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}

	public static ComparablePairs<Integer, Integer> create(int[] vec){
		ComparablePairs<Integer, Integer> pairs = new ComparablePairs<Integer, Integer>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}
	public static ComparablePairs<Integer, Integer> create(Integer[] vec){
		ComparablePairs<Integer, Integer> pairs = new ComparablePairs<Integer, Integer>(vec.length);
		for (int i = 0; i < vec.length; i++) {
			pairs.add(i, vec[i]);
		}
		return pairs;
	}
	
	public void outputToTextFile(String filePath){
		try {
			BufferedWriter writer = Files.newBufferedWriter(Paths.get(filePath));
			int count = 0;
			for (ComparablePair<K, V> item : this){
				writer.write(item.getKey() + "\t" + item.getValue() + "\n");
				count++;
				if ((count & 0xffff) == 0){
					// flush periodically
					writer.flush();
				}
			}
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
