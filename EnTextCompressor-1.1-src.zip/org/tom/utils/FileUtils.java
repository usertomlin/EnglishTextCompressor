package org.tom.utils;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.zip.GZIPInputStream;

/**
 * @author Tom3_Lin
 *
 */
public class FileUtils {
	@SuppressWarnings("unchecked")
	public static <T extends Serializable> T fromInputStream(InputStream inputStream) {
		try {
			ObjectInputStream ois = new ObjectInputStream(new GZIPInputStream(inputStream) );
			Object object = ois.readObject();
			ois.close();
			return (T) object;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
}
