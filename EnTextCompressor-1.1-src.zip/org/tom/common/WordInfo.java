package org.tom.common;

import java.io.Serializable;

/**
 * a temporary class
 * @author Tom3_Lin
 *
 */
public class WordInfo implements Serializable, Comparable<WordInfo> {

	private static final long serialVersionUID = 1L;

	private String pos;
	private long frequency;
	
	/**
	 * @return the pos
	 */
	public String getPos() {
		return pos;
	}

	/**
	 * @param pos the pos to set
	 */
	public void setPos(String pos) {
		this.pos = pos;
	}

	/**
	 * @return the frequency
	 */
	public long getFrequency() {
		return frequency;
	}

	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(long frequency) {
		this.frequency = frequency;
	}

	public WordInfo(String pos, long frequency) {
		this.pos = pos;
		this.frequency = frequency;
	}

	@Override
	public int compareTo(WordInfo o) {
		return (int) (frequency - o.frequency);
	}
	
	public String toString(){
		return pos + "-" + frequency;
	}
	
}
