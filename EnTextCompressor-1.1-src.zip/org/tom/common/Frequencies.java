package org.tom.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;


/**
 * for convenience of handling a large collection of items and their frequencies
 * @author Tom3_Lin
 *
 * @param <Key> Comparable types like String, Integer, etc.
 */
public class Frequencies<Key extends Comparable<Key>> extends HashMap<Key, Long> implements Serializable {
	
	private static final long serialVersionUID = 8117615765684788723L;
	
	private long totalFrequency;
	
	public Frequencies(){
		super();
	}
	
	public long getTotalFrequency(){
		if (totalFrequency == 0){
			Iterator<Entry<Key, Long>> iterator = entrySet().iterator();
			while (iterator.hasNext()){
				long freq = iterator.next().getValue();
				totalFrequency += freq;
			}
		}
		return totalFrequency;
	}
	
	public void setTotalFrequency(long totalFrequency){
		this.totalFrequency = totalFrequency;
	}
	
	public Frequencies(int initialCapacity) {
		super(initialCapacity);
	}

	public void incrementFrequency(Key key, long frequency) {
		Long freq = get(key);
		put(key, freq == null ? frequency : freq + frequency);
		totalFrequency += frequency;
	}
	
	public void addFrequency(Key key) {
		Long freq = get(key);
		put(key, freq == null ? 1L : freq + 1L);
		totalFrequency++;
	}
	
	public void addFrequency(Key key, long addition) {
		Long freq = get(key);
		put(key, freq == null ? addition : freq + addition);
		totalFrequency += addition;
	}
	
	public void put(Key key, int frequency){
		super.put(key, (long) frequency);
	}
	
	public void remove(Key key){
		Long freq = get(key);
		if (freq == null)
			return;
		super.remove(key);
		totalFrequency -= freq;
	}
	
	public void addFrequencies(Collection<Key> keys){
		for (Key key : keys) {
			addFrequency(key);
		}
	}
	public void addFrequencies(Key[] keys){
		for (Key key : keys) {
			addFrequency(key);
		}
	}
	
	
	public ArrayList<ComparablePair<Key, Long>> sortByKey() {	
		ArrayList<ComparablePair<Key, Long>> list = toList();
		list.sort(new Comparator<ComparablePair<Key, Long>>() {
			@Override
			public int compare(ComparablePair<Key, Long> o1, ComparablePair<Key, Long> o2) {
				return o1.getKey().compareTo(o2.getKey());
			}
		});
		return list;
	}
	
	public ArrayList<ComparablePair<Key, Long>> sortByFrequency() {
		ArrayList<ComparablePair<Key, Long>> list = toList();
		Collections.sort(list, descendingFrequencyComparator());
		return list;
	}
	
	public ArrayList<ComparablePair<Key, Long>> getItemsWithSortedFrequencies(){
		return sortByFrequency();
	}
	
	public ArrayList<ComparablePair<Key, Long>> sortByFrequency(int frequencyThreshold) {
		ArrayList<ComparablePair<Key, Long>> list = toList(frequencyThreshold);
		Collections.sort(list);
		return list;
	}
	
	

	
	/**get sorted pairs with the highest frequency values
	 * @param num
	 */
	public ArrayList<ComparablePair<Key, Long>> getTopFrequencyItems(int num) {
		PriorityQueue<ComparablePair<Key, Long>> queue = 
				new PriorityQueue<ComparablePair<Key,Long>>(ascendingFrequencyComparator());
		Iterator<Entry<Key, Long>> iterator = entrySet().iterator();
		while (iterator.hasNext()){
			Entry<Key, Long> entry = iterator.next();
			queue.add(new ComparablePair<Key, Long>(entry.getKey(), entry.getValue()));
			if (queue.size() > num){
				queue.remove();
			}
		}
		ArrayList<ComparablePair<Key, Long>> result = new ArrayList<ComparablePair<Key, Long>>(queue);
		Collections.sort(result, descendingFrequencyComparator());
		return result;
	}
	
	
	
	
	/**@return the key value pair with max frequency
	 */
	public ComparablePair<Key, Long> maxFrequencyPair(){
		Iterator<Entry<Key, Long>> iterator = entrySet().iterator();
		long maxFrequency = 0;
		Key itsKey = null;
		while (iterator.hasNext()){
			Entry<Key, Long> entry = iterator.next();
			if (entry.getValue() > maxFrequency ){
				maxFrequency = entry.getValue();
				itsKey = entry.getKey();
			}
		}
		return new ComparablePair<Key, Long>(itsKey, maxFrequency);
	}
	
	public ComparablePair<Key, Long> minFrequencyPair(){
		Iterator<Entry<Key, Long>> iterator = entrySet().iterator();
		long minFrequency = Long.MAX_VALUE;
		Key itsKey = null;
		while (iterator.hasNext()){
			Entry<Key, Long> entry = iterator.next();
			if (entry.getValue() < minFrequency ){
				minFrequency = entry.getValue();
				itsKey = entry.getKey();
			}
		}
		return new ComparablePair<Key, Long>(itsKey, minFrequency);
	}
	
	public ArrayList<ComparablePair<Key, Long>> toList(){
		return toList(Long.MIN_VALUE);
	}
	
	public ArrayList<ComparablePair<Key, Long>> toList(long freqThreshold){
		totalFrequency = 0;
		ArrayList<ComparablePair<Key, Long>> list = new ArrayList<>(size());
		Iterator<Entry<Key, Long>> iterator = entrySet().iterator();
		while (iterator.hasNext()){
			Entry<Key, Long> entry = iterator.next();
			if (entry.getValue() < freqThreshold)
				continue;
			totalFrequency += entry.getValue();
			list.add(new ComparablePair<Key, Long>(entry.getKey(), entry.getValue()));
		}
		return list;
	}
	
	public String toString(){
		ArrayList<ComparablePair<Key, Long>> sortedPairs = sortByFrequency();
		StringBuilder builder = new StringBuilder(sortedPairs.size() * 12);
		for (ComparablePair<Key, Long> pair : sortedPairs) {
			builder.append(pair.getKey() + "\t" + pair.getValue() + "\n");
		}
		return builder.toString();
	}
	
	public void filterByFrequency(int frequencyThreshold){
		Iterator<Entry<Key, Long>> iterator = entrySet().iterator();
		while (iterator.hasNext()){
			Entry<Key, Long> entry = iterator.next();
			if (entry.getValue() < frequencyThreshold){
				iterator.remove();
			}
		}
	}
	
	public void filterTopFrequencyItems(int numItems){
		ArrayList<ComparablePair<Key, Long>> items = getTopFrequencyItems(numItems);
		clear();
		for (ComparablePair<Key, Long> item : items) {
			put(item.getKey(), item.getValue());
		}
	}
	
	
	public void outputToTextFile(String filePath){
		ArrayList<ComparablePair<Key, Long>> items = sortByFrequency();
		try {
			
			FileOutputStream outputStream = new FileOutputStream(filePath);
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
			
			long currentFrequency = 0;
			int count = 0;
			for (ComparablePair<Key, Long> item : items){
				count++;
				currentFrequency += item.getValue();
				double cumulativePercentage = (currentFrequency + 0d) / totalFrequency;
				writer.write(item.getKey() + "\t" + item.getValue() + "\t" + cumulativePercentage + "\n");
				
				if ((count & 0xffff) == 0){
					// flush periodically
					writer.flush();
				}
			}
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public <NewKey extends Comparable<NewKey>> Frequencies<NewKey> toFrequenciesWithChangedKeys(Map<Key, NewKey> map){
		Frequencies<NewKey> frequencies = new Frequencies<NewKey>();
		Iterator<java.util.Map.Entry<Key, Long>> iterator = entrySet().iterator();
		while (iterator.hasNext()){
			Entry<Key, Long> entry = iterator.next();
			frequencies.addFrequency(map.get(entry.getKey()), entry.getValue());
		}
		return frequencies;
	}
	
	/**
	 * the format should be identical to outputToTextFile
	 */
	public static Frequencies<String> readFromTextFile(String filePath){
		try {
			Frequencies<String> frequencies = new Frequencies<String>();
			Path path = Paths.get(filePath);
			BufferedReader reader = Files.newBufferedReader(path);
			String line = null;
			while ((line = reader.readLine()) != null){
				int tabIndex1 = line.indexOf('\t');
				int tabIndex2 = line.lastIndexOf('\t');
				String key = line.substring(0, tabIndex1);
				long frequency = Long.parseLong(line.substring(tabIndex1 + 1, tabIndex2));
				frequencies.addFrequency(key, frequency);
			}
			reader.close();
			return frequencies;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**for sorting frequency in descending order
	 */

	public final Comparator<ComparablePair<Key, Long>> descendingFrequencyComparator() {
		return new Comparator<ComparablePair<Key, Long>>() {
			@Override
			public int compare(ComparablePair<Key, Long> o1, ComparablePair<Key, Long> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}
		};
	};
	
	public final Comparator<ComparablePair<Key, Long>> ascendingFrequencyComparator() {
		return new Comparator<ComparablePair<Key, Long>>() {
			@Override
			public int compare(ComparablePair<Key, Long> o1, ComparablePair<Key, Long> o2) {
				return o1.getValue().compareTo(o2.getValue());
			}
		};
	};
	
	/**for sorting keys in natural order
	 */
	public final Comparator<ComparablePair<Key, Long>> ascendingKeyComparator(){ 
		return new Comparator<ComparablePair<Key, Long>>() {
			@Override
			public int compare(ComparablePair<Key, Long> o1, ComparablePair<Key, Long> o2) {
				return o1.getKey().compareTo(o2.getKey());
			}
		};
	};

	public final Comparator<ComparablePair<Key, Long>> descendingKeyComparator(){ 
		return new Comparator<ComparablePair<Key, Long>>() {
			@Override
			public int compare(ComparablePair<Key, Long> o1, ComparablePair<Key, Long> o2) {
				return o2.getKey().compareTo(o1.getKey());
			}
		};
	};
}
