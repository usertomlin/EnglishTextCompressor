package org.tom.common;

import java.io.Serializable;

/**
 * converted from WordInfo
 * @author Tom3_Lin
 *
 */
public class WordInformation implements Serializable, Comparable<WordInformation> {

	private static final long serialVersionUID = 1L;

	private int posIndex;
	private int frequency;
	
	public WordInformation(int posIndex, int frequency) {
		this.posIndex = posIndex;
		this.frequency = frequency;
	}

	/**
	 * @return the posIndex
	 */
	public int getPosIndex() {
		return posIndex;
	}

	/**
	 * @param posIndex the posIndex to set
	 */
	public void setPosIndex(int posIndex) {
		this.posIndex = posIndex;
	}

	/**
	 * @return the frequency
	 */
	public int getFrequency() {
		return frequency;
	}

	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	@Override
	public int compareTo(WordInformation o) {
		return frequency - o.frequency;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[posIndex=" + posIndex + ", frequency=" + frequency + "]";
	}

	
	
}
