package org.tom.compression;

import gnu.trove.map.hash.TByteIntHashMap;

import java.io.Serializable;
import java.util.BitSet;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Map.Entry;

import org.tom.common.BinaryTree;
import org.tom.common.Frequencies;
import org.tom.common.MutableInt;
import org.tom.common.Pair;
import org.tom.utils.BitSetUtils;

/**
 * 
 * @author Tom3_Lin
 *
 */
public class HuffmanByteInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	private BinaryTree<Byte> decodeTree;
	private TByteIntHashMap encodePositionMap;

	public HuffmanByteInfo(BinaryTree<Byte> decodeTree, TByteIntHashMap encodePositionMap) {
		this.decodeTree = decodeTree;
		this.encodePositionMap = encodePositionMap;
	}
	
	/**
	 * should make sure the element exits
	 */
	public boolean[] getEncodeBits(byte element){
		int position = encodePositionMap.get(element);
		return BitSetUtils.toTraversalBits(position);
	}
	
	
	public byte getDecodedElement(BitSet bitSet, MutableInt offset){
		BinaryTree<Byte> target = decodeTree.traverseQuick(bitSet, offset);
		return target.getObject();
	}
	
	
	public static <T extends Comparable<T>> HuffmanByteInfo create(Frequencies<Byte> frequencies) {
		BinaryTree<Pair<Byte, Long>> treeWithValues = createHuffmanDecodeTreeWithValue(frequencies);
		BinaryTree<Byte> decodeTree = toTreeWithoutValues(treeWithValues);
		HashMap<Byte, Integer> encodePositionTempMap = decodeTree.getEncodePositionMap();
		
		TByteIntHashMap encodePositionMap = new TByteIntHashMap();
		Iterator<Entry<Byte, Integer>> iterator = encodePositionTempMap.entrySet().iterator();
		while (iterator.hasNext()){
			Entry<Byte, Integer> entry = iterator.next();
			encodePositionMap.put(entry.getKey(), entry.getValue());
		}
		return new HuffmanByteInfo(decodeTree, encodePositionMap);
	}
 
	
	private static <K> BinaryTree<K> toTreeWithoutValues(BinaryTree<Pair<K, Long>> treeWithValues){
		if (treeWithValues == null)
			return null;
		BinaryTree<K> treeWithoutValues = new BinaryTree<K>();
		
		treeWithoutValues.setObject(treeWithValues.getObject() == null ? null : treeWithValues.getObject().getKey());
		if (treeWithValues.getLeft() != null){
			BinaryTree<K> left = toTreeWithoutValues(treeWithValues.getLeft());
			treeWithoutValues.setLeft(left);
		}
		if (treeWithValues.getRight() != null){
			BinaryTree<K> right = toTreeWithoutValues(treeWithValues.getRight());
			treeWithoutValues.setRight(right);
		}
		return treeWithoutValues;
	}
	
	private static <T extends Comparable<T>> BinaryTree<Pair<T, Long>> createHuffmanDecodeTreeWithValue(
			HashMap<T, Long> frequencies) {
		
		PriorityQueue<BinaryTree<Pair<T, Long>>> priorityQueue = new PriorityQueue<>(
			new Comparator<BinaryTree<Pair<T, Long>>>() {
				@Override
				public int compare(BinaryTree<Pair<T, Long>> o1, BinaryTree<Pair<T, Long>> o2) {
					return o1.getObject().getValue().compareTo(o2.getObject().getValue());
			}
		});

		Iterator<Entry<T, Long>> iterator = frequencies.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<T, Long> entry = iterator.next();
			Pair<T, Long> comparablePair = new Pair<T, Long>(entry.getKey(), entry.getValue());
			priorityQueue.add(new BinaryTree<Pair<T, Long>>(comparablePair));
		}
		while (priorityQueue.size() > 1) {
			BinaryTree<Pair<T, Long>> t1 = priorityQueue.poll();
			BinaryTree<Pair<T, Long>> t2 = priorityQueue.poll();
			BinaryTree<Pair<T, Long>> merged = new BinaryTree<Pair<T, Long>>(t1, t2);
			merged.setObject(new Pair<T, Long>(null, t1.getObject().getValue() + t2.getObject().getValue()));
			priorityQueue.add(merged);
		}
		return priorityQueue.peek();
	}

	
	
	

}
