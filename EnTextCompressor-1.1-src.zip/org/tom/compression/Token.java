package org.tom.compression;

import java.io.Serializable;
import java.util.ArrayList;



/**
 * 
 * @author Tom3_Lin
 *
 */
public class Token implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public static final boolean isWord = true;
	public static final boolean isCharSequence = false;
	public static final boolean isFollowedBySpace = true;
	public static final boolean isNotFollowedBySpace = false;
	
	public static final byte PERIODPosIndex = 26;

	// a word or a char sequence
	private String token;
	
	//true: isWord; false: isCharSequence
	private transient boolean tokenType;
	
	//used only for a word token 
	private boolean isFollowedByASpace;

	//0: not a word; >0: its word index
	private transient int wordIndex;

	//start pos index of the word
	private transient byte startPosIndex; 




	//end pos index of the word
	private transient byte endPosIndex;
	
	
	public Token(String token, boolean tokenType, boolean isFollowByASpace, int wordIndex, byte posIndex) {
		this.token = token;
		this.tokenType = tokenType;
		this.isFollowedByASpace = isFollowByASpace;
		this.wordIndex = wordIndex;
		this.setEndPosIndex(this.startPosIndex = posIndex);
	}
	
	
	public Token simpleCopy(){
		Token copy = new Token(token, tokenType, false, wordIndex, startPosIndex);
		return copy;
	}
	
	public boolean isWord(){
		return tokenType == isWord;
	}
	
	public boolean isCharSequence(){
		return tokenType == isCharSequence;
	}
	
	public void appendTo(StringBuilder builder){
		builder.append(token);
		if (isFollowedByASpace){
			builder.append(' ');
		} 
	}
	
	public String toString2(){
		StringBuilder builder = new StringBuilder(token);
		if (isFollowedByASpace)
			builder.append("; isFollowedByASpace");
		if (tokenType == Token.isCharSequence) {
			builder.append("; tokenType = charSequence; posIndex = " + startPosIndex + ", wordIndex = " + wordIndex);
		} else{
			builder.append("; tokenType = word; posIndex = " + startPosIndex + ", wordIndex = " + wordIndex);
		}
		
		return builder.toString();
	}

	@Override
	public String toString(){
		if (isFollowedByASpace){
			return token + ' ';
		}
		return token;
	}
	
	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}


	/**
	 * @return the tokenType
	 */
	public boolean getTokenType() {
		return tokenType;
	}

	/**
	 * @param tokenType the tokenType to set
	 */
	public void setTokenType(boolean tokenType) {
		this.tokenType = tokenType;
	}

	/**
	 * @return the isFollowByASpace
	 */
	public boolean isFollowedByASpace() {
		return isFollowedByASpace;
	}

	/**
	 * @param isFollowedByASpace the isFollowByASpace to set
	 */
	public void setFollowedByASpace(boolean isFollowedByASpace) {
		this.isFollowedByASpace = isFollowedByASpace;
	}

	/**
	 * @return the wordIndex
	 */
	public int getWordIndex() {
		return wordIndex;
	}

	/**
	 * @param wordIndex the wordIndex to set
	 */
	public void setWordIndex(int wordIndex) {
		this.wordIndex = wordIndex;
	}

	/**
	 * @return the startPosIndex
	 */
	public byte getStartPosIndex() {
		return startPosIndex;
	}

	/**
	 * @param startPosIndex the startPosIndex to set
	 */
	public void setStartPosIndex(byte startPosIndex) {
		this.startPosIndex = startPosIndex;
	}

	/**
	 * @return the endPosIndex
	 */
	public byte getEndPosIndex() {
		return endPosIndex;
	}

	/**
	 * @param endPosIndex the endPosIndex to set
	 */
	public void setEndPosIndex(byte endPosIndex) {
		this.endPosIndex = endPosIndex;
	}
	
	/**
	 * a dummy word token, a PERIOD, 
	 */
	public static Token dummyFirstToken(){
		return new Token("", isWord, isNotFollowedBySpace, 0, PERIODPosIndex);
	}

	@Override
	public int hashCode() {
	    return token.hashCode() + (isFollowedByASpace ? 1231 : 1237);
	}

	@Override
	public boolean equals(Object obj) {
		Token other = (Token) obj;
		if (isFollowedByASpace != other.isFollowedByASpace)
			return false;
		return token.equals(other.token);
	}



	public static class Tokens extends ArrayList<Token> implements Comparable<Tokens>{

		private static final long serialVersionUID = 1L;

		public Tokens(int i) {
			super(i);
		}

		public Tokens() {
			
		}

		public Tokens subList(int fromIndex, int toIndex){
			Tokens tokens = new Tokens(toIndex - fromIndex);
			for (int i = fromIndex; i < toIndex; i++){
				tokens.add(get(i));
			}
			tokens.get(tokens.size() - 1).setFollowedByASpace(false);
			return tokens;
		}
		
		
		/**assume that obj is an instanceof Tokens,
		 * and the elements are never null 
		 */
		@Override
		public boolean equals(Object obj) {
			Tokens other = (Tokens) obj;
			final int size = size();
			if (size != other.size())
				return false;
			for (int i = 0; i < size; i++){
				if (get(i).equals(other.get(i)) == false){
					return false;
				}
			}
			return true;
		}

		@Override
		public int compareTo(Tokens o) {
			final int size = size();
			int comparison = size - o.size();
			if (comparison != 0)
				return comparison;
			for (int i = 0; i < size ; i++){
				comparison = get(i).getToken().compareTo(o.get(i).getToken());
				if (comparison != 0)
					return comparison;
			}
			return 0;
		}

		@Override
		public String toString(){
			StringBuilder builder = new StringBuilder(size() << 3);
			for (int i = 0; i < size(); i++){
				get(i).appendTo(builder);
			}
			return builder.toString();
		}
		
		
	}
	
}
