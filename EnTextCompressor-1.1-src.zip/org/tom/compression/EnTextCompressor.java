package org.tom.compression;

import java.util.BitSet;
import java.util.List;

import org.tom.common.MutableInt;
import org.tom.compression.CompressionBits;
import org.tom.compression.Token;
import org.tom.utils.FileUtils;

/**
 * @author Tom3_Lin
 */
public class EnTextCompressor {

	protected static EnTextCompressionInfo enTextCompressionInfo = 
			FileUtils.fromInputStream(EnTextCompressionInfo.class.getResourceAsStream("enTextCompressionInfo.ser.gz"));
	
	public static byte[] compress(String enText){
		CompressionBits compressionBits = new CompressionBits();
		List<Token> tokens = enTextCompressionInfo.tokenizeBySeparators(enText);
		
		final int numTokens = tokens.size();
		if (numTokens <= 1) {
			//empty text
			return new byte[0];
		}
		
		StringBuilder builder = new StringBuilder();
		for (int i = 1; i < numTokens; i++) {
			Token token1 = tokens.get(i - 1);
			Token token2 = tokens.get(i);
			enTextCompressionInfo.addEncodingBits(token1, token2, compressionBits);
			token2.appendTo(builder);
		}
		
		Token lastToken = tokens.get(numTokens - 1);
		if (lastToken.isWord() && lastToken.isFollowedByASpace()){
			int offset = compressionBits.getOffset().getInteger();
			compressionBits.getBitSet().set(offset);
		} 
		compressionBits.getOffset().increment();
		
		return compressionBits.toByteArray();
	}

	public static String uncompress(byte[] byteArray){
		if (byteArray == null)
			return null;
		if (byteArray.length == 0){
			return "";
		}
		CompressionBits compressionBits = CompressionBits.fromCompressedBytes(byteArray);
		BitSet bitSet = compressionBits.getBitSet();
		final int numBits = compressionBits.getOffset().getInteger();
		return uncompress(bitSet, numBits);
	}
	
	private static String uncompress(BitSet bitSet, final int numBits){
		StringBuilder builder = new StringBuilder();
		MutableInt offset = new MutableInt();
		final int numBitsMinus1 = numBits - 1;
		byte posIndex = enTextCompressionInfo.decodeAfterWord(bitSet, offset, builder, Token.PERIODPosIndex);
		while (offset.isSmallerThan(numBitsMinus1)){
			if (posIndex > 0) {
				posIndex = enTextCompressionInfo.decodeAfterWord(bitSet, offset, builder, posIndex);
			} else {
				posIndex = enTextCompressionInfo.decodeAfterCharSequence(bitSet, offset, builder, posIndex);
			}
		}
		if (posIndex > 0 && bitSet.get(numBitsMinus1)){
			builder.append(' ');
		}
		
		return builder.toString();
	}

	
}
